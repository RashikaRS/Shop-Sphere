package com.shopsphere.service;

import com.shopsphere.dto.WishlistResponse;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.User;
import com.shopsphere.entity.Wishlist;
import com.shopsphere.entity.WishlistItem;
import com.shopsphere.exception.ConflictException;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.ProductRepository;
import com.shopsphere.repository.UserRepository;
import com.shopsphere.repository.WishlistItemRepository;
import com.shopsphere.repository.WishlistRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WishlistService {

    private final WishlistRepository wishlistRepository;
    private final WishlistItemRepository wishlistItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Transactional
    public Wishlist getOrCreateWishlist(Long userId) {
        return wishlistRepository.findByUserId(userId).orElseGet(() -> {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
            Wishlist wishlist = Wishlist.builder().user(user).build();
            return wishlistRepository.save(wishlist);
        });
    }

    public WishlistResponse getWishlist(Long userId) {
        return toResponse(getOrCreateWishlist(userId));
    }

    @Transactional
    public WishlistResponse addItem(Long userId, Long productId) {
        Wishlist wishlist = getOrCreateWishlist(userId);
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + productId));

        wishlistItemRepository.findByWishlistIdAndProductId(wishlist.getId(), productId).ifPresent(i -> {
            throw new ConflictException("Product is already in your wishlist");
        });

        WishlistItem item = WishlistItem.builder().wishlist(wishlist).product(product).build();
        wishlistItemRepository.save(item);

        Wishlist refreshed = wishlistRepository.findByUserId(userId).orElseThrow();
        return toResponse(refreshed);
    }

    @Transactional
    public WishlistResponse removeItem(Long userId, Long itemId) {
        Wishlist wishlist = getOrCreateWishlist(userId);
        WishlistItem item = wishlist.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Wishlist item not found with id: " + itemId));
        wishlistItemRepository.delete(item);

        Wishlist refreshed = wishlistRepository.findByUserId(userId).orElseThrow();
        return toResponse(refreshed);
    }

    private WishlistResponse toResponse(Wishlist wishlist) {
        List<WishlistResponse.WishlistItemResponse> items = wishlist.getItems().stream().map(item -> {
            Product p = item.getProduct();
            String imageUrl = p.getImages().isEmpty() ? null : p.getImages().get(0).getImageUrl();
            return WishlistResponse.WishlistItemResponse.builder()
                    .itemId(item.getId())
                    .productId(p.getId())
                    .productName(p.getName())
                    .imageUrl(imageUrl)
                    .price(p.getPrice())
                    .availableStock(p.getStockQuantity())
                    .build();
        }).toList();

        return WishlistResponse.builder()
                .wishlistId(wishlist.getId())
                .items(items)
                .build();
    }
}
