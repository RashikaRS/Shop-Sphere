package com.shopsphere.controller;

import com.shopsphere.dto.*;
import com.shopsphere.service.AdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
 * All endpoints here are restricted to ROLE_ADMIN by SecurityConfig's
 * "/api/admin/**" rule - no per-method checks needed.
 */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/dashboard/stats")
    public DashboardStatsResponse getStats() {
        return adminService.getDashboardStats();
    }

    @GetMapping("/products/low-stock")
    public PageResponse<ProductResponse> getLowStockProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return adminService.getLowStockProducts(page, size);
    }

    @GetMapping("/orders")
    public PageResponse<AdminOrderSummary> getAllOrders(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return adminService.getAllOrders(status, page, size);
    }

    @PutMapping("/orders/{id}/status")
    public AdminOrderSummary updateOrderStatus(@PathVariable Long id,
                                                @Valid @RequestBody OrderStatusUpdateRequest request) {
        return adminService.updateOrderStatus(id, request.getStatus());
    }

    @GetMapping("/users")
    public List<AdminUserSummary> getAllUsers() {
        return adminService.getAllUsers();
    }

    @PutMapping("/users/{id}/enable")
    public AdminUserSummary enableUser(@PathVariable Long id) {
        return adminService.setUserEnabled(id, true);
    }

    @PutMapping("/users/{id}/disable")
    public AdminUserSummary disableUser(@PathVariable Long id) {
        return adminService.setUserEnabled(id, false);
    }
}
