package com.shopsphere.service;

import com.shopsphere.dto.CouponApplyResponse;
import com.shopsphere.dto.CouponDto;
import com.shopsphere.entity.Coupon;
import com.shopsphere.entity.CouponUsage;
import com.shopsphere.entity.User;
import com.shopsphere.exception.BadRequestException;
import com.shopsphere.exception.ConflictException;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.CouponRepository;
import com.shopsphere.repository.CouponUsageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CouponService {

    private final CouponRepository couponRepository;
    private final CouponUsageRepository couponUsageRepository;

    public List<CouponDto> getAll() {
        return couponRepository.findAll().stream().map(this::toDto).toList();
    }

    public CouponDto create(CouponDto request) {
        couponRepository.findByCodeIgnoreCase(request.getCode()).ifPresent(c -> {
            throw new ConflictException("A coupon with this code already exists");
        });
        Coupon coupon = fromDto(new Coupon(), request);
        return toDto(couponRepository.save(coupon));
    }

    public CouponDto update(Long id, CouponDto request) {
        Coupon coupon = couponRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coupon not found with id: " + id));
        fromDto(coupon, request);
        return toDto(couponRepository.save(coupon));
    }

    public void delete(Long id) {
        if (!couponRepository.existsById(id)) {
            throw new ResourceNotFoundException("Coupon not found with id: " + id);
        }
        couponRepository.deleteById(id);
    }

    /**
     * Validates a coupon code against the given cart total and the user's redemption
     * history, WITHOUT recording a usage. Used for a checkout preview.
     */
    public CouponApplyResponse previewDiscount(Long userId, String code, BigDecimal cartTotal) {
        Coupon coupon = getValidCoupon(code, userId, cartTotal);
        BigDecimal discount = computeDiscount(coupon, cartTotal);
        BigDecimal newTotal = cartTotal.subtract(discount).max(BigDecimal.ZERO);
        return CouponApplyResponse.builder()
                .code(coupon.getCode())
                .discount(discount)
                .newTotal(newTotal)
                .build();
    }

    /**
     * Validates and returns the discount amount for use during checkout. Does NOT
     * record usage here - the caller (OrderService) records CouponUsage only after
     * the order is actually created, inside the same transaction.
     */
    public Coupon validateForCheckout(String code, Long userId, BigDecimal cartTotal) {
        return getValidCoupon(code, userId, cartTotal);
    }

    public BigDecimal computeDiscount(Coupon coupon, BigDecimal cartTotal) {
        BigDecimal discount = BigDecimal.ZERO;
        if (coupon.getDiscountPercent() != null && coupon.getDiscountPercent().compareTo(BigDecimal.ZERO) > 0) {
            discount = cartTotal.multiply(coupon.getDiscountPercent())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        } else if (coupon.getDiscountAmount() != null) {
            discount = coupon.getDiscountAmount();
        }
        // Discount can never exceed the cart total
        return discount.min(cartTotal);
    }

    @Transactional
    public void recordUsage(Coupon coupon, User user) {
        CouponUsage usage = CouponUsage.builder().coupon(coupon).user(user).build();
        couponUsageRepository.save(usage);
    }

    private Coupon getValidCoupon(String code, Long userId, BigDecimal cartTotal) {
        Coupon coupon = couponRepository.findByCodeIgnoreCase(code)
                .orElseThrow(() -> new BadRequestException("Invalid coupon code"));

        if (!Boolean.TRUE.equals(coupon.getIsActive())) {
            throw new BadRequestException("This coupon is no longer active");
        }

        LocalDate today = LocalDate.now();
        if (coupon.getValidFrom() != null && today.isBefore(coupon.getValidFrom())) {
            throw new BadRequestException("This coupon is not valid yet");
        }
        if (coupon.getValidUntil() != null && today.isAfter(coupon.getValidUntil())) {
            throw new BadRequestException("This coupon has expired");
        }

        if (coupon.getMinOrderValue() != null && cartTotal.compareTo(coupon.getMinOrderValue()) < 0) {
            throw new BadRequestException("Minimum order value for this coupon is " + coupon.getMinOrderValue());
        }

        long usageCount = couponUsageRepository.countByCouponIdAndUserId(coupon.getId(), userId);
        int maxUsage = coupon.getMaxUsagePerUser() != null ? coupon.getMaxUsagePerUser() : 1;
        if (usageCount >= maxUsage) {
            throw new BadRequestException("You have already used this coupon the maximum number of times");
        }

        return coupon;
    }

    private Coupon fromDto(Coupon coupon, CouponDto dto) {
        coupon.setCode(dto.getCode());
        coupon.setDiscountPercent(dto.getDiscountPercent());
        coupon.setDiscountAmount(dto.getDiscountAmount());
        coupon.setMinOrderValue(dto.getMinOrderValue() != null ? dto.getMinOrderValue() : BigDecimal.ZERO);
        coupon.setMaxUsagePerUser(dto.getMaxUsagePerUser() != null ? dto.getMaxUsagePerUser() : 1);
        coupon.setValidFrom(dto.getValidFrom());
        coupon.setValidUntil(dto.getValidUntil());
        coupon.setIsActive(dto.getIsActive() == null || dto.getIsActive());
        return coupon;
    }

    private CouponDto toDto(Coupon c) {
        return CouponDto.builder()
                .id(c.getId())
                .code(c.getCode())
                .discountPercent(c.getDiscountPercent())
                .discountAmount(c.getDiscountAmount())
                .minOrderValue(c.getMinOrderValue())
                .maxUsagePerUser(c.getMaxUsagePerUser())
                .validFrom(c.getValidFrom())
                .validUntil(c.getValidUntil())
                .isActive(c.getIsActive())
                .build();
    }
}
