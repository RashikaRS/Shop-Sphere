package com.shopsphere.controller;

import com.shopsphere.dto.WishlistResponse;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.WishlistService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wishlist")
@RequiredArgsConstructor
public class WishlistController {

    private final WishlistService wishlistService;

    @GetMapping
    public WishlistResponse getWishlist(@AuthenticationPrincipal UserPrincipal principal) {
        return wishlistService.getWishlist(principal.getId());
    }

    @PostMapping("/items/{productId}")
    public ResponseEntity<WishlistResponse> addItem(@AuthenticationPrincipal UserPrincipal principal,
                                                      @PathVariable Long productId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(wishlistService.addItem(principal.getId(), productId));
    }

    @DeleteMapping("/items/{itemId}")
    public WishlistResponse removeItem(@AuthenticationPrincipal UserPrincipal principal,
                                        @PathVariable Long itemId) {
        return wishlistService.removeItem(principal.getId(), itemId);
    }
}
