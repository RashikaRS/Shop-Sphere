package com.shopsphere.service;

import com.shopsphere.dto.PageResponse;
import com.shopsphere.dto.ReviewRequest;
import com.shopsphere.dto.ReviewResponse;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.Review;
import com.shopsphere.entity.User;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.ProductRepository;
import com.shopsphere.repository.ReviewRepository;
import com.shopsphere.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public PageResponse<ReviewResponse> getReviewsForProduct(Long productId, int page, int size) {
        PageRequest pageRequest = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50));
        Page<Review> reviews = reviewRepository.findByProductIdOrderByCreatedAtDesc(productId, pageRequest);

        List<ReviewResponse> content = reviews.getContent().stream().map(this::toResponse).toList();

        return PageResponse.<ReviewResponse>builder()
                .content(content)
                .pageNumber(reviews.getNumber())
                .pageSize(reviews.getSize())
                .totalElements(reviews.getTotalElements())
                .totalPages(reviews.getTotalPages())
                .last(reviews.isLast())
                .build();
    }

    /**
     * Creates a new review, or updates the user's existing review for this product
     * if one already exists (one review per user per product).
     */
    @Transactional
    public ReviewResponse upsertReview(Long userId, Long productId, ReviewRequest request) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + productId));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        Review review = reviewRepository.findByProductIdAndUserId(productId, userId)
                .orElseGet(() -> Review.builder().product(product).user(user).build());

        review.setRating(request.getRating());
        review.setComment(request.getComment());
        review = reviewRepository.save(review);

        recalculateAverageRating(product);

        return toResponse(review);
    }

    @Transactional
    public void deleteReview(Long userId, boolean isAdmin, Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + reviewId));

        if (!isAdmin && !review.getUser().getId().equals(userId)) {
            throw new ResourceNotFoundException("Review not found with id: " + reviewId);
        }

        Product product = review.getProduct();
        reviewRepository.delete(review);
        recalculateAverageRating(product);
    }

    private void recalculateAverageRating(Product product) {
        List<Review> all = reviewRepository.findByProductId(product.getId());
        if (all.isEmpty()) {
            product.setAverageRating(BigDecimal.ZERO);
        } else {
            double avg = all.stream().mapToInt(Review::getRating).average().orElse(0.0);
            product.setAverageRating(BigDecimal.valueOf(avg).setScale(1, RoundingMode.HALF_UP));
        }
        productRepository.save(product);
    }

    private ReviewResponse toResponse(Review review) {
        return ReviewResponse.builder()
                .id(review.getId())
                .userId(review.getUser().getId())
                .userName(review.getUser().getFullName())
                .rating(review.getRating())
                .comment(review.getComment())
                .createdAt(review.getCreatedAt())
                .build();
    }
}
