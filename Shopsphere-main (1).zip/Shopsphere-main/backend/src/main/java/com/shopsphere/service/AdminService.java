package com.shopsphere.service;

import com.shopsphere.dto.*;
import com.shopsphere.entity.Order;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.Role;
import com.shopsphere.entity.User;
import com.shopsphere.exception.BadRequestException;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.OrderRepository;
import com.shopsphere.repository.ProductRepository;
import com.shopsphere.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class AdminService {

    private static final int LOW_STOCK_THRESHOLD = 10;
    private static final Set<String> VALID_STATUSES = Set.of("PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELLED");

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    public DashboardStatsResponse getDashboardStats() {
        long totalUsers = userRepository.count();
        long totalProducts = productRepository.count();
        long totalOrders = orderRepository.count();
        BigDecimal totalRevenue = orderRepository.sumRevenue();
        long pendingOrders = orderRepository.countByStatus("PENDING");
        long lowStockCount = productRepository.countByStockQuantityLessThanEqual(LOW_STOCK_THRESHOLD);

        List<DashboardStatsResponse.StatusCount> byStatus = orderRepository.countGroupedByStatus().stream()
                .map(row -> DashboardStatsResponse.StatusCount.builder()
                        .status((String) row[0])
                        .count((Long) row[1])
                        .build())
                .toList();

        return DashboardStatsResponse.builder()
                .totalUsers(totalUsers)
                .totalProducts(totalProducts)
                .totalOrders(totalOrders)
                .totalRevenue(totalRevenue != null ? totalRevenue : BigDecimal.ZERO)
                .pendingOrders(pendingOrders)
                .lowStockCount(lowStockCount)
                .ordersByStatus(byStatus)
                .build();
    }

    public PageResponse<ProductResponse> getLowStockProducts(int page, int size) {
        List<Product> lowStock = productRepository.findLowStock(LOW_STOCK_THRESHOLD);
        int from = Math.min(page * size, lowStock.size());
        int to = Math.min(from + size, lowStock.size());
        List<ProductResponse> content = lowStock.subList(from, to).stream().map(this::toProductResponse).toList();

        return PageResponse.<ProductResponse>builder()
                .content(content)
                .pageNumber(page)
                .pageSize(size)
                .totalElements(lowStock.size())
                .totalPages((int) Math.ceil((double) lowStock.size() / size))
                .last(to >= lowStock.size())
                .build();
    }

    public PageResponse<AdminOrderSummary> getAllOrders(String status, int page, int size) {
        PageRequest pageRequest = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100));
        Page<Order> orders = (status == null || status.isBlank())
                ? orderRepository.findAllByOrderByCreatedAtDesc(pageRequest)
                : orderRepository.findByStatusOrderByCreatedAtDesc(status.toUpperCase(), pageRequest);

        List<AdminOrderSummary> content = orders.getContent().stream().map(o -> AdminOrderSummary.builder()
                .id(o.getId())
                .customerName(o.getUser().getFullName())
                .customerEmail(o.getUser().getEmail())
                .status(o.getStatus())
                .totalAmount(o.getTotalAmount())
                .createdAt(o.getCreatedAt())
                .itemCount(o.getItems().size())
                .build()).toList();

        return PageResponse.<AdminOrderSummary>builder()
                .content(content)
                .pageNumber(orders.getNumber())
                .pageSize(orders.getSize())
                .totalElements(orders.getTotalElements())
                .totalPages(orders.getTotalPages())
                .last(orders.isLast())
                .build();
    }

    @Transactional
    public AdminOrderSummary updateOrderStatus(Long orderId, String newStatus) {
        if (!VALID_STATUSES.contains(newStatus.toUpperCase())) {
            throw new BadRequestException("Invalid status. Must be one of: " + VALID_STATUSES);
        }
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));
        order.setStatus(newStatus.toUpperCase());
        order = orderRepository.save(order);

        return AdminOrderSummary.builder()
                .id(order.getId())
                .customerName(order.getUser().getFullName())
                .customerEmail(order.getUser().getEmail())
                .status(order.getStatus())
                .totalAmount(order.getTotalAmount())
                .createdAt(order.getCreatedAt())
                .itemCount(order.getItems().size())
                .build();
    }

    public List<AdminUserSummary> getAllUsers() {
        return userRepository.findAll().stream().map(this::toUserSummary).toList();
    }

    @Transactional
    public AdminUserSummary setUserEnabled(Long userId, boolean enabled) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        user.setEnabled(enabled);
        return toUserSummary(userRepository.save(user));
    }

    private AdminUserSummary toUserSummary(User user) {
        return AdminUserSummary.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .enabled(user.getEnabled())
                .roles(user.getRoles().stream().map(Role::getName).toList())
                .createdAt(user.getCreatedAt())
                .build();
    }

    private ProductResponse toProductResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .stockQuantity(product.getStockQuantity())
                .categoryId(product.getCategory() != null ? product.getCategory().getId() : null)
                .categoryName(product.getCategory() != null ? product.getCategory().getName() : null)
                .averageRating(product.getAverageRating())
                .isActive(product.getIsActive())
                .imageUrls(product.getImages().stream().map(i -> i.getImageUrl()).toList())
                .build();
    }
}
