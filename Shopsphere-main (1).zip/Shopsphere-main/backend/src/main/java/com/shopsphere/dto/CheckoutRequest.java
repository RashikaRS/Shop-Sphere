package com.shopsphere.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CheckoutRequest {
    @NotNull(message = "addressId is required")
    private Long addressId;

    // Optional - coupon support added fully in Phase 7
    private String couponCode;
}
