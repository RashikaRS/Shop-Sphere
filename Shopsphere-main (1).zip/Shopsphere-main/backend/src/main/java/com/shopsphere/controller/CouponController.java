package com.shopsphere.controller;

import com.shopsphere.dto.CouponApplyRequest;
import com.shopsphere.dto.CouponApplyResponse;
import com.shopsphere.dto.CouponDto;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.CouponService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coupons")
@RequiredArgsConstructor
public class CouponController {

    private final CouponService couponService;

    @GetMapping
    public List<CouponDto> getAll() {
        return couponService.getAll();
    }

    @PostMapping
    public ResponseEntity<CouponDto> create(@Valid @RequestBody CouponDto request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(couponService.create(request));
    }

    @PutMapping("/{id}")
    public CouponDto update(@PathVariable Long id, @Valid @RequestBody CouponDto request) {
        return couponService.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        couponService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/apply")
    public CouponApplyResponse apply(@AuthenticationPrincipal UserPrincipal principal,
                                      @Valid @RequestBody CouponApplyRequest request) {
        return couponService.previewDiscount(principal.getId(), request.getCode(), request.getCartTotal());
    }
}
