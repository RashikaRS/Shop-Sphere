package com.shopsphere.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CouponApplyRequest {
    @NotBlank(message = "code is required")
    private String code;

    @NotNull(message = "cartTotal is required")
    private BigDecimal cartTotal;
}
