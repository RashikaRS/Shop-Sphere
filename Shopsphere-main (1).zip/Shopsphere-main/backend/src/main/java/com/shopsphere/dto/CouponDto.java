package com.shopsphere.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CouponDto {
    private Long id;

    @NotBlank(message = "Coupon code is required")
    private String code;

    private BigDecimal discountPercent;
    private BigDecimal discountAmount;
    private BigDecimal minOrderValue;
    private Integer maxUsagePerUser;
    private LocalDate validFrom;
    private LocalDate validUntil;
    private Boolean isActive;
}
