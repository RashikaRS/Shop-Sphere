package com.shopsphere.service;

import com.shopsphere.dto.AddressDto;
import com.shopsphere.dto.CheckoutRequest;
import com.shopsphere.dto.OrderResponse;
import com.shopsphere.dto.PageResponse;
import com.shopsphere.entity.*;
import com.shopsphere.exception.BadRequestException;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final AddressRepository addressRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final CouponService couponService;

    @Transactional
    public OrderResponse checkout(Long userId, CheckoutRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        Address address = addressRepository.findById(request.getAddressId())
                .orElseThrow(() -> new ResourceNotFoundException("Address not found with id: " + request.getAddressId()));
        if (!address.getUser().getId().equals(userId)) {
            throw new ResourceNotFoundException("Address not found with id: " + request.getAddressId());
        }

        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new BadRequestException("Your cart is empty"));

        if (cart.getItems().isEmpty()) {
            throw new BadRequestException("Your cart is empty");
        }

        // Validate stock for every item before committing anything
        for (CartItem item : cart.getItems()) {
            Product product = item.getProduct();
            if (product.getStockQuantity() < item.getQuantity()) {
                throw new BadRequestException(
                        "Not enough stock for \"" + product.getName() + "\". Available: " + product.getStockQuantity());
            }
        }

        BigDecimal subtotal = cart.getItems().stream()
                .map(i -> i.getProduct().getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Coupon is optional. If provided, it's validated and its usage recorded
        // in this same transaction, so a failed order never consumes a redemption.
        com.shopsphere.entity.Coupon appliedCoupon = null;
        BigDecimal discount = BigDecimal.ZERO;
        if (request.getCouponCode() != null && !request.getCouponCode().isBlank()) {
            appliedCoupon = couponService.validateForCheckout(request.getCouponCode(), userId, subtotal);
            discount = couponService.computeDiscount(appliedCoupon, subtotal);
        }
        BigDecimal total = subtotal.subtract(discount);

        Order order = Order.builder()
                .user(user)
                .address(address)
                .coupon(appliedCoupon)
                .subtotal(subtotal)
                .discount(discount)
                .totalAmount(total)
                .status("PENDING")
                .build();

        order = orderRepository.save(order);

        if (appliedCoupon != null) {
            couponService.recordUsage(appliedCoupon, user);
        }

        for (CartItem item : cart.getItems()) {
            Product product = item.getProduct();

            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .product(product)
                    .quantity(item.getQuantity())
                    .unitPrice(product.getPrice())
                    .build();
            order.getItems().add(orderItem);

            // Decrement stock now that the order is confirmed
            product.setStockQuantity(product.getStockQuantity() - item.getQuantity());
            productRepository.save(product);
        }

        order = orderRepository.save(order);

        // Clear the cart now that checkout succeeded
        cart.getItems().clear();
        cartRepository.save(cart);

        return toResponse(order);
    }

    public PageResponse<OrderResponse> getUserOrders(Long userId, int page, int size) {
        PageRequest pageRequest = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50));
        Page<Order> orders = orderRepository.findByUserIdOrderByCreatedAtDesc(userId, pageRequest);

        List<OrderResponse> content = orders.getContent().stream().map(this::toResponse).toList();

        return PageResponse.<OrderResponse>builder()
                .content(content)
                .pageNumber(orders.getNumber())
                .pageSize(orders.getSize())
                .totalElements(orders.getTotalElements())
                .totalPages(orders.getTotalPages())
                .last(orders.isLast())
                .build();
    }

    public OrderResponse getOrderById(Long userId, Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));
        if (!order.getUser().getId().equals(userId)) {
            throw new ResourceNotFoundException("Order not found with id: " + orderId);
        }
        return toResponse(order);
    }

    private OrderResponse toResponse(Order order) {
        List<OrderResponse.OrderItemResponse> items = order.getItems().stream().map(item -> {
            Product p = item.getProduct();
            String imageUrl = p.getImages().isEmpty() ? null : p.getImages().get(0).getImageUrl();
            BigDecimal lineTotal = item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            return OrderResponse.OrderItemResponse.builder()
                    .productId(p.getId())
                    .productName(p.getName())
                    .imageUrl(imageUrl)
                    .quantity(item.getQuantity())
                    .unitPrice(item.getUnitPrice())
                    .lineTotal(lineTotal)
                    .build();
        }).toList();

        AddressDto addressDto = null;
        if (order.getAddress() != null) {
            Address a = order.getAddress();
            addressDto = AddressDto.builder()
                    .id(a.getId())
                    .fullName(a.getFullName())
                    .phone(a.getPhone())
                    .line1(a.getLine1())
                    .line2(a.getLine2())
                    .city(a.getCity())
                    .state(a.getState())
                    .postalCode(a.getPostalCode())
                    .country(a.getCountry())
                    .build();
        }

        return OrderResponse.builder()
                .id(order.getId())
                .status(order.getStatus())
                .subtotal(order.getSubtotal())
                .discount(order.getDiscount())
                .totalAmount(order.getTotalAmount())
                .createdAt(order.getCreatedAt())
                .shippingAddress(addressDto)
                .items(items)
                .build();
    }
}
