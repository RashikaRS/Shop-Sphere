package com.shopsphere.service;

import com.shopsphere.dto.PageResponse;
import com.shopsphere.dto.ProductRequest;
import com.shopsphere.dto.ProductResponse;
import com.shopsphere.entity.Category;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.ProductImage;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.CategoryRepository;
import com.shopsphere.repository.ProductRepository;
import com.shopsphere.repository.spec.ProductSpecifications;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public PageResponse<ProductResponse> search(String search, Long categoryId,
                                                 BigDecimal minPrice, BigDecimal maxPrice,
                                                 String sortBy, String sortDir,
                                                 int page, int size, boolean adminView) {

        Sort.Direction direction = "desc".equalsIgnoreCase(sortDir) ? Sort.Direction.DESC : Sort.Direction.ASC;
        String sortField = switch (sortBy == null ? "" : sortBy) {
            case "price" -> "price";
            case "rating" -> "averageRating";
            case "name" -> "name";
            default -> "createdAt";
        };

        PageRequest pageRequest = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100),
                Sort.by(direction, sortField));

        var spec = ProductSpecifications.build(search, categoryId, minPrice, maxPrice, !adminView);
        Page<Product> resultPage = productRepository.findAll(spec, pageRequest);

        List<ProductResponse> content = resultPage.getContent().stream().map(this::toResponse).toList();

        return PageResponse.<ProductResponse>builder()
                .content(content)
                .pageNumber(resultPage.getNumber())
                .pageSize(resultPage.getSize())
                .totalElements(resultPage.getTotalElements())
                .totalPages(resultPage.getTotalPages())
                .last(resultPage.isLast())
                .build();
    }

    public ProductResponse getById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        return toResponse(product);
    }

    public ProductResponse create(ProductRequest request) {
        Product product = Product.builder()
                .name(request.getName())
                .description(request.getDescription())
                .price(request.getPrice())
                .stockQuantity(request.getStockQuantity())
                .isActive(request.getIsActive() == null || request.getIsActive())
                .build();

        applyCategory(product, request.getCategoryId());
        applyImages(product, request.getImageUrls());

        return toResponse(productRepository.save(product));
    }

    public ProductResponse update(Long id, ProductRequest request) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));

        product.setName(request.getName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setStockQuantity(request.getStockQuantity());
        if (request.getIsActive() != null) product.setIsActive(request.getIsActive());

        applyCategory(product, request.getCategoryId());

        if (request.getImageUrls() != null) {
            product.getImages().clear();
            applyImages(product, request.getImageUrls());
        }

        return toResponse(productRepository.save(product));
    }

    public void delete(Long id) {
        if (!productRepository.existsById(id)) {
            throw new ResourceNotFoundException("Product not found with id: " + id);
        }
        productRepository.deleteById(id);
    }

    private void applyCategory(Product product, Long categoryId) {
        if (categoryId == null) {
            product.setCategory(null);
            return;
        }
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + categoryId));
        product.setCategory(category);
    }

    private void applyImages(Product product, List<String> imageUrls) {
        if (imageUrls == null) return;
        List<ProductImage> images = new ArrayList<>();
        for (int i = 0; i < imageUrls.size(); i++) {
            images.add(ProductImage.builder()
                    .product(product)
                    .imageUrl(imageUrls.get(i))
                    .isPrimary(i == 0)
                    .build());
        }
        product.getImages().addAll(images);
    }

    /**
     * Simple recommendation strategy: other active products in the same category,
     * highest-rated first, excluding the product itself. Falls back to top-rated
     * products overall if the product has no category or no category-mates.
     */
    public List<ProductResponse> getRecommendations(Long productId, int limit) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + productId));

        PageRequest pageRequest = PageRequest.of(0, Math.min(Math.max(limit, 1), 20),
                Sort.by(Sort.Direction.DESC, "averageRating"));

        Long categoryId = product.getCategory() != null ? product.getCategory().getId() : null;
        var spec = ProductSpecifications.build(null, categoryId, null, null, true);

        List<Product> candidates = productRepository.findAll(spec, pageRequest).getContent().stream()
                .filter(p -> !p.getId().equals(productId))
                .toList();

        if (candidates.isEmpty() && categoryId != null) {
            // No other products in the same category - fall back to top-rated overall
            var fallbackSpec = ProductSpecifications.build(null, null, null, null, true);
            candidates = productRepository.findAll(fallbackSpec, pageRequest).getContent().stream()
                    .filter(p -> !p.getId().equals(productId))
                    .toList();
        }

        return candidates.stream().map(this::toResponse).toList();
    }

    private ProductResponse toResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .stockQuantity(product.getStockQuantity())
                .categoryId(product.getCategory() != null ? product.getCategory().getId() : null)
                .categoryName(product.getCategory() != null ? product.getCategory().getName() : null)
                .averageRating(product.getAverageRating())
                .isActive(product.getIsActive())
                .imageUrls(product.getImages().stream().map(ProductImage::getImageUrl).toList())
                .build();
    }
}
