package com.shopsphere.service;

import com.razorpay.RazorpayClient;
import com.razorpay.Utils;
import com.shopsphere.dto.PaymentStatusResponse;
import com.shopsphere.dto.PaymentVerificationRequest;
import com.shopsphere.dto.RazorpayOrderResponse;
import com.shopsphere.entity.Order;
import com.shopsphere.entity.Payment;
import com.shopsphere.exception.BadRequestException;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.OrderRepository;
import com.shopsphere.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final RazorpayClient razorpayClient;
    private final OrderRepository orderRepository;
    private final PaymentRepository paymentRepository;

    @Value("${razorpay.key-id}")
    private String razorpayKeyId;

    @Value("${razorpay.key-secret}")
    private String razorpayKeySecret;

    /**
     * Creates a Razorpay Order (test mode) for an existing ShopSphere order and
     * records a local Payment row in CREATED status. The frontend uses the returned
     * razorpayOrderId + keyId to launch Razorpay Checkout.
     */
    @Transactional
    public RazorpayOrderResponse createRazorpayOrder(Long userId, Long orderId) {
        Order order = getOwnedOrder(userId, orderId);

        if ("PAID".equals(order.getStatus())) {
            throw new BadRequestException("This order has already been paid for.");
        }
        if ("CANCELLED".equals(order.getStatus())) {
            throw new BadRequestException("This order was cancelled and cannot be paid for.");
        }

        long amountInPaise = order.getTotalAmount()
                .multiply(BigDecimal.valueOf(100))
                .longValueExact();

        try {
            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise);
            options.put("currency", "INR");
            options.put("receipt", "shopsphere_order_" + order.getId());

            com.razorpay.Order razorpayOrder = razorpayClient.orders.create(options);
            String razorpayOrderId = razorpayOrder.get("id");

            // Reuse an existing Payment row for this order if a previous attempt exists (retry flow)
            Payment payment = paymentRepository.findByOrderId(order.getId()).orElseGet(() ->
                    Payment.builder().order(order).build());

            payment.setRazorpayOrderId(razorpayOrderId);
            payment.setAmount(order.getTotalAmount());
            payment.setCurrency("INR");
            payment.setStatus("CREATED");
            paymentRepository.save(payment);

            return RazorpayOrderResponse.builder()
                    .internalOrderId(order.getId())
                    .razorpayOrderId(razorpayOrderId)
                    .amountInPaise(amountInPaise)
                    .currency("INR")
                    .keyId(razorpayKeyId)
                    .build();

        } catch (Exception e) {
            throw new BadRequestException("Could not initiate payment. Please try again. (" + e.getMessage() + ")");
        }
    }

    /**
     * Verifies the Razorpay payment signature SERVER-SIDE using the key secret.
     * This is the step that actually confirms the payment is genuine - the frontend
     * callback alone can never be trusted, since it's just JS running in the browser.
     */
    @Transactional
    public PaymentStatusResponse verifyPayment(Long userId, PaymentVerificationRequest request) {
        Order order = getOwnedOrder(userId, request.getOrderId());

        Payment payment = paymentRepository.findByOrderId(order.getId())
                .orElseThrow(() -> new ResourceNotFoundException("No payment attempt found for this order"));

        if (!payment.getRazorpayOrderId().equals(request.getRazorpayOrderId())) {
            throw new BadRequestException("Razorpay order ID does not match this payment attempt.");
        }

        JSONObject attributes = new JSONObject();
        attributes.put("razorpay_order_id", request.getRazorpayOrderId());
        attributes.put("razorpay_payment_id", request.getRazorpayPaymentId());
        attributes.put("razorpay_signature", request.getRazorpaySignature());

        boolean isValid;
        try {
            isValid = Utils.verifyPaymentSignature(attributes, razorpayKeySecret);
        } catch (Exception e) {
            isValid = false;
        }

        payment.setRazorpayPaymentId(request.getRazorpayPaymentId());
        payment.setRazorpaySignature(request.getRazorpaySignature());

        if (isValid) {
            payment.setStatus("SUCCESS");
            order.setStatus("PAID");
        } else {
            payment.setStatus("FAILED");
            // Order stays PENDING so the user can retry payment.
        }

        paymentRepository.save(payment);
        orderRepository.save(order);

        if (!isValid) {
            throw new BadRequestException("Payment verification failed. Please try again.");
        }

        return toStatusResponse(order, payment);
    }

    public PaymentStatusResponse getPaymentStatus(Long userId, Long orderId) {
        Order order = getOwnedOrder(userId, orderId);
        Payment payment = paymentRepository.findByOrderId(orderId).orElse(null);
        return toStatusResponse(order, payment);
    }

    private Order getOwnedOrder(Long userId, Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));
        if (!order.getUser().getId().equals(userId)) {
            throw new ResourceNotFoundException("Order not found with id: " + orderId);
        }
        return order;
    }

    private PaymentStatusResponse toStatusResponse(Order order, Payment payment) {
        return PaymentStatusResponse.builder()
                .orderId(order.getId())
                .orderStatus(order.getStatus())
                .paymentStatus(payment != null ? payment.getStatus() : "NONE")
                .amount(order.getTotalAmount())
                .razorpayOrderId(payment != null ? payment.getRazorpayOrderId() : null)
                .razorpayPaymentId(payment != null ? payment.getRazorpayPaymentId() : null)
                .build();
    }
}
