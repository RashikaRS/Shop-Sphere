package com.shopsphere.controller;

import com.shopsphere.dto.PaymentStatusResponse;
import com.shopsphere.dto.PaymentVerificationRequest;
import com.shopsphere.dto.RazorpayOrderResponse;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/create-order/{orderId}")
    public RazorpayOrderResponse createOrder(@AuthenticationPrincipal UserPrincipal principal,
                                              @PathVariable Long orderId) {
        return paymentService.createRazorpayOrder(principal.getId(), orderId);
    }

    @PostMapping("/verify")
    public PaymentStatusResponse verify(@AuthenticationPrincipal UserPrincipal principal,
                                         @Valid @RequestBody PaymentVerificationRequest request) {
        return paymentService.verifyPayment(principal.getId(), request);
    }

    @GetMapping("/status/{orderId}")
    public PaymentStatusResponse status(@AuthenticationPrincipal UserPrincipal principal,
                                         @PathVariable Long orderId) {
        return paymentService.getPaymentStatus(principal.getId(), orderId);
    }
}
