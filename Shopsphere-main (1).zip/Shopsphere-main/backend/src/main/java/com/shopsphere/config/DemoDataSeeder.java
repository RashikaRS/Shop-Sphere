package com.shopsphere.config;

import com.shopsphere.entity.Category;
import com.shopsphere.entity.Coupon;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.ProductImage;
import com.shopsphere.repository.CategoryRepository;
import com.shopsphere.repository.CouponRepository;
import com.shopsphere.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/*
 * Seeds a handful of demo products (and a demo coupon) on first run so the
 * storefront has content to search/filter/paginate through and a coupon to
 * test at checkout. Only runs if the respective table is empty, so it's safe
 * to leave in for repeated app restarts.
 */
@Component
@RequiredArgsConstructor
public class DemoDataSeeder implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final CouponRepository couponRepository;

    @Override
    public void run(String... args) {
        seedProducts();
        seedCoupon();
    }

    private void seedCoupon() {
        if (couponRepository.count() > 0) return;
        Coupon welcome = Coupon.builder()
                .code("WELCOME10")
                .discountPercent(BigDecimal.TEN)
                .minOrderValue(BigDecimal.valueOf(20))
                .maxUsagePerUser(1)
                .validFrom(LocalDate.now().minusDays(1))
                .validUntil(LocalDate.now().plusMonths(6))
                .isActive(true)
                .build();
        couponRepository.save(welcome);
    }

    private void seedProducts() {
        if (productRepository.count() > 0) return;

        Category electronics = categoryRepository.findByName("Electronics").orElse(null);
        Category fashion = categoryRepository.findByName("Fashion").orElse(null);
        Category home = categoryRepository.findByName("Home & Kitchen").orElse(null);
        Category books = categoryRepository.findByName("Books").orElse(null);

        List<Product> demo = List.of(
                product("Wireless Bluetooth Headphones", "Over-ear headphones with 30-hour battery life and noise cancellation.",
                        new BigDecimal("59.99"), 50, electronics, "https://picsum.photos/seed/headphones/500"),
                product("Smartphone Stand", "Adjustable aluminum stand compatible with all phone sizes.",
                        new BigDecimal("14.99"), 120, electronics, "https://picsum.photos/seed/phonestand/500"),
                product("Mechanical Keyboard", "RGB backlit mechanical keyboard with blue switches.",
                        new BigDecimal("74.50"), 35, electronics, "https://picsum.photos/seed/keyboard/500"),
                product("Men's Casual Shirt", "100% cotton slim-fit casual shirt, machine washable.",
                        new BigDecimal("24.99"), 80, fashion, "https://picsum.photos/seed/shirt/500"),
                product("Women's Running Shoes", "Lightweight breathable running shoes with cushioned sole.",
                        new BigDecimal("49.99"), 60, fashion, "https://picsum.photos/seed/shoes/500"),
                product("Leather Wallet", "Genuine leather bifold wallet with RFID protection.",
                        new BigDecimal("19.99"), 100, fashion, "https://picsum.photos/seed/wallet/500"),
                product("Non-Stick Frying Pan", "12-inch non-stick frying pan, oven safe up to 450F.",
                        new BigDecimal("29.99"), 40, home, "https://picsum.photos/seed/pan/500"),
                product("Electric Kettle", "1.7L stainless steel electric kettle with auto shut-off.",
                        new BigDecimal("22.50"), 55, home, "https://picsum.photos/seed/kettle/500"),
                product("Cotton Bedsheet Set", "Queen size 100% cotton bedsheet set with 2 pillow covers.",
                        new BigDecimal("34.99"), 30, home, "https://picsum.photos/seed/bedsheet/500"),
                product("The Pragmatic Programmer", "A classic book on software craftsmanship.",
                        new BigDecimal("39.99"), 25, books, "https://picsum.photos/seed/book1/500"),
                product("Atomic Habits", "A guide to building good habits and breaking bad ones.",
                        new BigDecimal("16.99"), 90, books, "https://picsum.photos/seed/book2/500"),
                product("Notebook Set (3-Pack)", "A5 ruled notebooks, 100 pages each, hardcover.",
                        new BigDecimal("9.99"), 200, books, "https://picsum.photos/seed/notebook/500")
        );

        productRepository.saveAll(demo);
    }

    private Product product(String name, String description, BigDecimal price, int stock, Category category, String imageUrl) {
        Product p = Product.builder()
                .name(name)
                .description(description)
                .price(price)
                .stockQuantity(stock)
                .category(category)
                .isActive(true)
                .averageRating(BigDecimal.valueOf(4.0))
                .build();
        ProductImage image = ProductImage.builder().product(p).imageUrl(imageUrl).isPrimary(true).build();
        p.getImages().add(image);
        return p;
    }
}
