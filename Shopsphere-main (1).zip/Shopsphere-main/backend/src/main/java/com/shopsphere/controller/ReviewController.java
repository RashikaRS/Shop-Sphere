package com.shopsphere.controller;

import com.shopsphere.dto.PageResponse;
import com.shopsphere.dto.ReviewRequest;
import com.shopsphere.dto.ReviewResponse;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping("/api/products/{productId}/reviews")
    public PageResponse<ReviewResponse> getReviews(@PathVariable Long productId,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "10") int size) {
        return reviewService.getReviewsForProduct(productId, page, size);
    }

    @PostMapping("/api/products/{productId}/reviews")
    public ResponseEntity<ReviewResponse> upsertReview(@AuthenticationPrincipal UserPrincipal principal,
                                                        @PathVariable Long productId,
                                                        @Valid @RequestBody ReviewRequest request) {
        ReviewResponse response = reviewService.upsertReview(principal.getId(), productId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @DeleteMapping("/api/reviews/{reviewId}")
    public ResponseEntity<Void> deleteReview(@AuthenticationPrincipal UserPrincipal principal,
                                              @PathVariable Long reviewId) {
        boolean isAdmin = principal.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        reviewService.deleteReview(principal.getId(), isAdmin, reviewId);
        return ResponseEntity.noContent().build();
    }
}
