package com.shopsphere.controller;

import com.shopsphere.dto.CheckoutRequest;
import com.shopsphere.dto.OrderResponse;
import com.shopsphere.dto.PageResponse;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/checkout")
    public ResponseEntity<OrderResponse> checkout(@AuthenticationPrincipal UserPrincipal principal,
                                                    @Valid @RequestBody CheckoutRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(orderService.checkout(principal.getId(), request));
    }

    @GetMapping
    public PageResponse<OrderResponse> getOrders(@AuthenticationPrincipal UserPrincipal principal,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "10") int size) {
        return orderService.getUserOrders(principal.getId(), page, size);
    }

    @GetMapping("/{id}")
    public OrderResponse getOrderById(@AuthenticationPrincipal UserPrincipal principal, @PathVariable Long id) {
        return orderService.getOrderById(principal.getId(), id);
    }
}
