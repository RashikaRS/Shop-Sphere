package com.shopsphere.service;

import com.shopsphere.dto.CartItemRequest;
import com.shopsphere.dto.CartResponse;
import com.shopsphere.entity.Cart;
import com.shopsphere.entity.CartItem;
import com.shopsphere.entity.Product;
import com.shopsphere.entity.User;
import com.shopsphere.exception.ResourceNotFoundException;
import com.shopsphere.repository.CartItemRepository;
import com.shopsphere.repository.CartRepository;
import com.shopsphere.repository.ProductRepository;
import com.shopsphere.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Transactional
    public Cart getOrCreateCart(Long userId) {
        return cartRepository.findByUserId(userId).orElseGet(() -> {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
            Cart cart = Cart.builder().user(user).build();
            return cartRepository.save(cart);
        });
    }

    public CartResponse getCart(Long userId) {
        Cart cart = getOrCreateCart(userId);
        return toResponse(cart);
    }

    @Transactional
    public CartResponse addItem(Long userId, CartItemRequest request) {
        Cart cart = getOrCreateCart(userId);
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + request.getProductId()));

        CartItem existing = cartItemRepository.findByCartIdAndProductId(cart.getId(), product.getId()).orElse(null);

        int desiredQty = request.getQuantity() + (existing != null ? existing.getQuantity() : 0);
        int cappedQty = Math.min(desiredQty, Math.max(product.getStockQuantity(), 0));
        if (cappedQty < 1) cappedQty = Math.min(desiredQty, 1); // still allow adding even if stock is 0, capped view-side

        if (existing != null) {
            existing.setQuantity(cappedQty);
            cartItemRepository.save(existing);
        } else {
            CartItem item = CartItem.builder()
                    .cart(cart)
                    .product(product)
                    .quantity(Math.min(request.getQuantity(), Math.max(product.getStockQuantity(), request.getQuantity())))
                    .build();
            cartItemRepository.save(item);
        }

        Cart refreshed = cartRepository.findByUserId(userId).orElseThrow();
        return toResponse(refreshed);
    }

    @Transactional
    public CartResponse updateItemQuantity(Long userId, Long itemId, int quantity) {
        Cart cart = getOrCreateCart(userId);
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found with id: " + itemId));

        if (quantity < 1) {
            cartItemRepository.delete(item);
        } else {
            int capped = Math.min(quantity, Math.max(item.getProduct().getStockQuantity(), quantity));
            item.setQuantity(capped);
            cartItemRepository.save(item);
        }

        Cart refreshed = cartRepository.findByUserId(userId).orElseThrow();
        return toResponse(refreshed);
    }

    @Transactional
    public CartResponse removeItem(Long userId, Long itemId) {
        Cart cart = getOrCreateCart(userId);
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found with id: " + itemId));
        cartItemRepository.delete(item);

        Cart refreshed = cartRepository.findByUserId(userId).orElseThrow();
        return toResponse(refreshed);
    }

    @Transactional
    public void clearCart(Long userId) {
        Cart cart = getOrCreateCart(userId);
        cart.getItems().clear();
        cartRepository.save(cart);
    }

    private CartResponse toResponse(Cart cart) {
        List<CartResponse.CartItemResponse> items = cart.getItems().stream().map(item -> {
            Product p = item.getProduct();
            BigDecimal lineTotal = p.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            String imageUrl = p.getImages().isEmpty() ? null : p.getImages().get(0).getImageUrl();
            return CartResponse.CartItemResponse.builder()
                    .itemId(item.getId())
                    .productId(p.getId())
                    .productName(p.getName())
                    .imageUrl(imageUrl)
                    .unitPrice(p.getPrice())
                    .quantity(item.getQuantity())
                    .lineTotal(lineTotal)
                    .availableStock(p.getStockQuantity())
                    .build();
        }).toList();

        BigDecimal subtotal = items.stream().map(CartResponse.CartItemResponse::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        int totalItems = items.stream().mapToInt(CartResponse.CartItemResponse::getQuantity).sum();

        return CartResponse.builder()
                .cartId(cart.getId())
                .items(items)
                .subtotal(subtotal)
                .totalItems(totalItems)
                .build();
    }
}
