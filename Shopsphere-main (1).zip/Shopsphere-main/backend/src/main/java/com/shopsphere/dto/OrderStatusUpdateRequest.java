package com.shopsphere.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OrderStatusUpdateRequest {
    @NotBlank(message = "status is required")
    private String status; // PENDING, PAID, SHIPPED, DELIVERED, CANCELLED
}
