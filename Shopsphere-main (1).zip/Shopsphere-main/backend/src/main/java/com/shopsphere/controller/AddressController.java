package com.shopsphere.controller;

import com.shopsphere.dto.AddressDto;
import com.shopsphere.security.UserPrincipal;
import com.shopsphere.service.AddressService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/addresses")
@RequiredArgsConstructor
public class AddressController {

    private final AddressService addressService;

    @GetMapping
    public List<AddressDto> getAll(@AuthenticationPrincipal UserPrincipal principal) {
        return addressService.getUserAddresses(principal.getId());
    }

    @PostMapping
    public ResponseEntity<AddressDto> create(@AuthenticationPrincipal UserPrincipal principal,
                                              @Valid @RequestBody AddressDto request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(addressService.create(principal.getId(), request));
    }

    @PutMapping("/{id}")
    public AddressDto update(@AuthenticationPrincipal UserPrincipal principal,
                              @PathVariable Long id,
                              @Valid @RequestBody AddressDto request) {
        return addressService.update(principal.getId(), id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@AuthenticationPrincipal UserPrincipal principal, @PathVariable Long id) {
        addressService.delete(principal.getId(), id);
        return ResponseEntity.noContent().build();
    }
}
