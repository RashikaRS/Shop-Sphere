package com.shopsphere.service;

import com.shopsphere.entity.Coupon;
import com.shopsphere.repository.CouponRepository;
import com.shopsphere.repository.CouponUsageRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CouponServiceTest {

    private final CouponService couponService = new CouponService(
            org.mockito.Mockito.mock(CouponRepository.class),
            org.mockito.Mockito.mock(CouponUsageRepository.class)
    );

    @Test
    void percentDiscount_isCalculatedCorrectly() {
        Coupon coupon = Coupon.builder()
                .code("SAVE10")
                .discountPercent(BigDecimal.TEN)
                .build();

        BigDecimal discount = couponService.computeDiscount(coupon, new BigDecimal("100.00"));

        assertEquals(new BigDecimal("10.00"), discount);
    }

    @Test
    void flatDiscount_isReturnedDirectly() {
        Coupon coupon = Coupon.builder()
                .code("FLAT5")
                .discountAmount(new BigDecimal("5.00"))
                .build();

        BigDecimal discount = couponService.computeDiscount(coupon, new BigDecimal("50.00"));

        assertEquals(new BigDecimal("5.00"), discount);
    }

    @Test
    void discount_neverExceedsCartTotal() {
        // A flat $50 discount on a $20 cart should cap at $20, never go negative.
        Coupon coupon = Coupon.builder()
                .code("BIG50")
                .discountAmount(new BigDecimal("50.00"))
                .build();

        BigDecimal discount = couponService.computeDiscount(coupon, new BigDecimal("20.00"));

        assertEquals(new BigDecimal("20.00"), discount);
    }

    @Test
    void noDiscountFields_resultsInZeroDiscount() {
        Coupon coupon = Coupon.builder().code("EMPTY").build();

        BigDecimal discount = couponService.computeDiscount(coupon, new BigDecimal("100.00"));

        assertEquals(BigDecimal.ZERO, discount);
    }
}
