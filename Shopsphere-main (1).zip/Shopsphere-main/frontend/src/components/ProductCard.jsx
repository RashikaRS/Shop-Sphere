import { Link } from 'react-router-dom'

export default function ProductCard({ product }) {
  const image = product.imageUrls?.[0] || 'https://picsum.photos/seed/placeholder/500'
  return (
    <Link to={`/products/${product.id}`} className="product-card">
      <img src={image} alt={product.name} loading="lazy" />
      <div className="product-card-body">
        <h3>{product.name}</h3>
        {product.categoryName && <span className="product-category">{product.categoryName}</span>}
        <div className="product-card-footer">
          <span className="product-price">${Number(product.price).toFixed(2)}</span>
          {product.stockQuantity === 0 && <span className="out-of-stock">Out of stock</span>}
        </div>
      </div>
    </Link>
  )
}
