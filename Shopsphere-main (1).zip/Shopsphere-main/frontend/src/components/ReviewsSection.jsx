import { useEffect, useState } from 'react'
import { fetchReviews, submitReview, deleteReview } from '../services/reviewService'
import { useAuth } from '../context/AuthContext'

export default function ReviewsSection({ productId, onRatingChange }) {
  const { user } = useAuth()
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const load = () => {
    setLoading(true)
    fetchReviews(productId, { page: 0, size: 20 })
      .then((res) => setReviews(res.data.content))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [productId])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      await submitReview(productId, { rating, comment })
      setComment('')
      load()
      if (onRatingChange) onRatingChange()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not submit review.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (reviewId) => {
    await deleteReview(reviewId)
    load()
    if (onRatingChange) onRatingChange()
  }

  return (
    <section className="reviews-section">
      <h3>Reviews</h3>

      {user && (
        <form className="review-form" onSubmit={handleSubmit}>
          {error && <p className="status-error">{error}</p>}
          <label>Your rating</label>
          <select value={rating} onChange={(e) => setRating(Number(e.target.value))}>
            {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} star{r > 1 ? 's' : ''}</option>)}
          </select>
          <textarea
            placeholder="Share your thoughts about this product..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
          />
          <button type="submit" className="add-to-cart-btn" disabled={submitting}>
            {submitting ? 'Submitting...' : 'Submit Review'}
          </button>
        </form>
      )}

      {loading ? (
        <p>Loading reviews...</p>
      ) : reviews.length === 0 ? (
        <p className="empty-state">No reviews yet. Be the first to review this product!</p>
      ) : (
        <div className="review-list">
          {reviews.map((r) => (
            <div className="review-item" key={r.id}>
              <div className="review-header">
                <strong>{r.userName}</strong>
                <span className="review-stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
                {user?.id === r.userId && (
                  <button className="remove-btn" onClick={() => handleDelete(r.id)}>Delete</button>
                )}
              </div>
              {r.comment && <p>{r.comment}</p>}
              <span className="review-date">{new Date(r.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
