import { useEffect, useState } from 'react'
import { fetchRecommendations } from '../services/reviewService'
import ProductCard from './ProductCard'

export default function RecommendedProducts({ productId }) {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetchRecommendations(productId, 4).then((res) => setProducts(res.data)).catch(() => {})
  }, [productId])

  if (products.length === 0) return null

  return (
    <section className="recommendations-section">
      <h3>You might also like</h3>
      <div className="products-grid">
        {products.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>
    </section>
  )
}
