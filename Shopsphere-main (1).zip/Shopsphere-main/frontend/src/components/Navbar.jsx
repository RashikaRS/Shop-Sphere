import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth()
  const { cart } = useCart()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login')
    setMenuOpen(false)
  }

  const closeMenu = () => setMenuOpen(false)

  return (
    <header className="navbar">
      <Link to="/" className="navbar-logo" onClick={closeMenu}>ShopSphere</Link>

      <button className="navbar-toggle" onClick={() => setMenuOpen((o) => !o)} aria-label="Toggle menu">
        &#9776;
      </button>

      <nav className={menuOpen ? 'navbar-links open' : 'navbar-links'}>
        <Link to="/products" onClick={closeMenu}>Products</Link>
        {user ? (
          <>
            <Link to="/wishlist" onClick={closeMenu}>Wishlist</Link>
            <Link to="/orders" onClick={closeMenu}>Orders</Link>
            <Link to="/addresses" onClick={closeMenu}>Addresses</Link>
            <Link to="/cart" className="cart-link" onClick={closeMenu}>
              Cart
              {cart.totalItems > 0 && <span className="cart-badge">{cart.totalItems}</span>}
            </Link>
            <span className="navbar-user">Hi, {user.fullName?.split(' ')[0]}</span>
            {isAdmin && <Link to="/admin" onClick={closeMenu}>Admin</Link>}
            <button className="link-btn" onClick={handleLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" onClick={closeMenu}>Login</Link>
            <Link to="/register" onClick={closeMenu}>Register</Link>
          </>
        )}
      </nav>
    </header>
  )
}
