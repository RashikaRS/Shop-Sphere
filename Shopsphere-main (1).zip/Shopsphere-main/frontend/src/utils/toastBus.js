const listeners = new Set()

export const toastBus = {
  emit(message, type = 'info') {
    listeners.forEach((fn) => fn({ message, type }))
  },
  subscribe(fn) {
    listeners.add(fn)
    return () => listeners.delete(fn)
  },
}
