import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import {
  fetchDashboardStats, fetchLowStockProducts, fetchAllOrders, updateOrderStatus,
  fetchAllUsers, enableUser, disableUser,
  createProduct, deleteProduct, fetchAllCoupons, createCoupon, deleteCoupon,
} from '../services/adminService'
import { fetchProducts, fetchCategories } from '../services/productService'

const TABS = ['Overview', 'Orders', 'Users', 'Products', 'Coupons']
const ORDER_STATUSES = ['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED']

export default function AdminDashboard() {
  const { user } = useAuth()
  const [tab, setTab] = useState('Overview')

  return (
    <main className="admin-page">
      <h1>Admin Dashboard</h1>
      <p>Welcome, {user?.fullName}</p>

      <div className="admin-tabs">
        {TABS.map((t) => (
          <button key={t} className={t === tab ? 'admin-tab active' : 'admin-tab'} onClick={() => setTab(t)}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && <OverviewTab />}
      {tab === 'Orders' && <OrdersTab />}
      {tab === 'Users' && <UsersTab />}
      {tab === 'Products' && <ProductsTab />}
      {tab === 'Coupons' && <CouponsTab />}
    </main>
  )
}

function OverviewTab() {
  const [stats, setStats] = useState(null)
  const [lowStock, setLowStock] = useState([])

  useEffect(() => {
    fetchDashboardStats().then((res) => setStats(res.data))
    fetchLowStockProducts({ page: 0, size: 10 }).then((res) => setLowStock(res.data.content))
  }, [])

  if (!stats) return <p>Loading stats...</p>

  return (
    <div>
      <div className="stats-grid">
        <StatCard label="Total Users" value={stats.totalUsers} />
        <StatCard label="Total Products" value={stats.totalProducts} />
        <StatCard label="Total Orders" value={stats.totalOrders} />
        <StatCard label="Total Revenue" value={`$${Number(stats.totalRevenue).toFixed(2)}`} />
        <StatCard label="Pending Orders" value={stats.pendingOrders} />
        <StatCard label="Low Stock Items" value={stats.lowStockCount} warn={stats.lowStockCount > 0} />
      </div>

      <h3>Orders by Status</h3>
      <div className="stats-grid">
        {stats.ordersByStatus?.map((s) => (
          <StatCard key={s.status} label={s.status} value={s.count} />
        ))}
      </div>

      <h3>Low Stock Products (&le;10 units)</h3>
      {lowStock.length === 0 ? (
        <p className="empty-state">No low-stock products right now.</p>
      ) : (
        <div className="cart-list">
          {lowStock.map((p) => (
            <div className="cart-row" key={p.id}>
              <div className="cart-row-info">
                <h3>{p.name}</h3>
                <p>{p.categoryName || 'Uncategorized'}</p>
              </div>
              <span className="status-error">{p.stockQuantity} left</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function StatCard({ label, value, warn }) {
  return (
    <div className={warn ? 'stat-card warn' : 'stat-card'}>
      <span className="stat-value">{value}</span>
      <span className="stat-label">{label}</span>
    </div>
  )
}

function OrdersTab() {
  const [orders, setOrders] = useState([])
  const [statusFilter, setStatusFilter] = useState('')
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    fetchAllOrders({ status: statusFilter || undefined, page: 0, size: 50 })
      .then((res) => setOrders(res.data.content))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [statusFilter])

  const handleStatusChange = async (orderId, newStatus) => {
    await updateOrderStatus(orderId, newStatus)
    load()
  }

  return (
    <div>
      <label>Filter by status: </label>
      <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
        <option value="">All</option>
        {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>

      {loading ? <p>Loading orders...</p> : (
        <div className="cart-list" style={{ marginTop: 16 }}>
          {orders.map((o) => (
            <div className="cart-row" key={o.id}>
              <div className="cart-row-info">
                <h3>Order #{o.id} &middot; {o.customerName}</h3>
                <p>{o.customerEmail} &middot; {o.itemCount} item(s) &middot; {new Date(o.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="cart-row-total">${Number(o.totalAmount).toFixed(2)}</div>
              <select value={o.status} onChange={(e) => handleStatusChange(o.id, e.target.value)}>
                {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          ))}
          {orders.length === 0 && <p className="empty-state">No orders found.</p>}
        </div>
      )}
    </div>
  )
}

function UsersTab() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    fetchAllUsers().then((res) => setUsers(res.data)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleToggle = async (u) => {
    if (u.enabled) await disableUser(u.id)
    else await enableUser(u.id)
    load()
  }

  if (loading) return <p>Loading users...</p>

  return (
    <div className="cart-list">
      {users.map((u) => (
        <div className="cart-row" key={u.id}>
          <div className="cart-row-info">
            <h3>{u.fullName} {u.roles.includes('ROLE_ADMIN') && <span className="product-category">Admin</span>}</h3>
            <p>{u.email} &middot; {u.phone || 'No phone'}</p>
          </div>
          <span className={u.enabled ? 'status-ok' : 'status-error'}>{u.enabled ? 'Active' : 'Disabled'}</span>
          <button className={u.enabled ? 'remove-btn' : 'add-to-cart-btn'} onClick={() => handleToggle(u)}>
            {u.enabled ? 'Disable' : 'Enable'}
          </button>
        </div>
      ))}
    </div>
  )
}

const emptyProductForm = { name: '', description: '', price: '', stockQuantity: '', categoryId: '', imageUrls: '' }

function ProductsTab() {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyProductForm)
  const [error, setError] = useState('')

  const load = () => {
    setLoading(true)
    fetchProducts({ page: 0, size: 50 }).then((res) => setProducts(res.data.content)).finally(() => setLoading(false))
    fetchCategories().then((res) => setCategories(res.data))
  }

  useEffect(() => { load() }, [])

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await createProduct({
        name: form.name,
        description: form.description,
        price: parseFloat(form.price),
        stockQuantity: parseInt(form.stockQuantity, 10),
        categoryId: form.categoryId || null,
        imageUrls: form.imageUrls ? form.imageUrls.split(',').map((s) => s.trim()) : [],
      })
      setForm(emptyProductForm)
      setShowForm(false)
      load()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create product.')
    }
  }

  const handleDelete = async (id) => {
    await deleteProduct(id)
    load()
  }

  return (
    <div>
      {!showForm && <button className="cta-link" style={{ border: 'none', cursor: 'pointer' }} onClick={() => setShowForm(true)}>+ Add New Product</button>}

      {showForm && (
        <form className="address-form" onSubmit={handleSubmit}>
          {error && <p className="status-error">{error}</p>}
          <input name="name" placeholder="Product name" value={form.name} onChange={handleChange} required />
          <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} rows={2} />
          <div className="price-range">
            <input name="price" type="number" step="0.01" placeholder="Price" value={form.price} onChange={handleChange} required />
            <input name="stockQuantity" type="number" placeholder="Stock quantity" value={form.stockQuantity} onChange={handleChange} required />
          </div>
          <select name="categoryId" value={form.categoryId} onChange={handleChange}>
            <option value="">No category</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input name="imageUrls" placeholder="Image URLs (comma-separated)" value={form.imageUrls} onChange={handleChange} />
          <div className="product-actions">
            <button type="submit" className="add-to-cart-btn">Create Product</button>
            <button type="button" className="wishlist-btn" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      )}

      {loading ? <p>Loading products...</p> : (
        <div className="cart-list" style={{ marginTop: 16 }}>
          {products.map((p) => (
            <div className="cart-row" key={p.id}>
              <img src={p.imageUrls?.[0] || 'https://picsum.photos/seed/placeholder/500'} alt={p.name} />
              <div className="cart-row-info">
                <h3>{p.name}</h3>
                <p>{p.categoryName || 'Uncategorized'} &middot; Stock: {p.stockQuantity}</p>
              </div>
              <div className="cart-row-total">${Number(p.price).toFixed(2)}</div>
              <button className="remove-btn" onClick={() => handleDelete(p.id)}>Delete</button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

const emptyCouponForm = { code: '', discountPercent: '', discountAmount: '', minOrderValue: '', maxUsagePerUser: 1, validFrom: '', validUntil: '' }

function CouponsTab() {
  const [coupons, setCoupons] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyCouponForm)
  const [error, setError] = useState('')

  const load = () => {
    setLoading(true)
    fetchAllCoupons().then((res) => setCoupons(res.data)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await createCoupon({
        code: form.code,
        discountPercent: form.discountPercent ? parseFloat(form.discountPercent) : null,
        discountAmount: form.discountAmount ? parseFloat(form.discountAmount) : null,
        minOrderValue: form.minOrderValue ? parseFloat(form.minOrderValue) : 0,
        maxUsagePerUser: parseInt(form.maxUsagePerUser, 10) || 1,
        validFrom: form.validFrom || null,
        validUntil: form.validUntil || null,
        isActive: true,
      })
      setForm(emptyCouponForm)
      setShowForm(false)
      load()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create coupon.')
    }
  }

  const handleDelete = async (id) => {
    await deleteCoupon(id)
    load()
  }

  return (
    <div>
      {!showForm && <button className="cta-link" style={{ border: 'none', cursor: 'pointer' }} onClick={() => setShowForm(true)}>+ Add New Coupon</button>}

      {showForm && (
        <form className="address-form" onSubmit={handleSubmit}>
          {error && <p className="status-error">{error}</p>}
          <input name="code" placeholder="Coupon code (e.g. SAVE20)" value={form.code} onChange={handleChange} required />
          <div className="price-range">
            <input name="discountPercent" type="number" placeholder="Discount %" value={form.discountPercent} onChange={handleChange} />
            <input name="discountAmount" type="number" placeholder="Or flat discount $" value={form.discountAmount} onChange={handleChange} />
          </div>
          <div className="price-range">
            <input name="minOrderValue" type="number" placeholder="Min order value" value={form.minOrderValue} onChange={handleChange} />
            <input name="maxUsagePerUser" type="number" placeholder="Max uses per user" value={form.maxUsagePerUser} onChange={handleChange} />
          </div>
          <div className="price-range">
            <input name="validFrom" type="date" value={form.validFrom} onChange={handleChange} />
            <input name="validUntil" type="date" value={form.validUntil} onChange={handleChange} />
          </div>
          <div className="product-actions">
            <button type="submit" className="add-to-cart-btn">Create Coupon</button>
            <button type="button" className="wishlist-btn" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      )}

      {loading ? <p>Loading coupons...</p> : (
        <div className="cart-list" style={{ marginTop: 16 }}>
          {coupons.map((c) => (
            <div className="cart-row" key={c.id}>
              <div className="cart-row-info">
                <h3>{c.code}</h3>
                <p>
                  {c.discountPercent ? `${c.discountPercent}% off` : `$${c.discountAmount} off`}
                  {' '}&middot; Min order: ${c.minOrderValue} &middot; Max uses/user: {c.maxUsagePerUser}
                </p>
              </div>
              <span className={c.isActive ? 'status-ok' : 'status-error'}>{c.isActive ? 'Active' : 'Inactive'}</span>
              <button className="remove-btn" onClick={() => handleDelete(c.id)}>Delete</button>
            </div>
          ))}
          {coupons.length === 0 && <p className="empty-state">No coupons yet.</p>}
        </div>
      )}
    </div>
  )
}
