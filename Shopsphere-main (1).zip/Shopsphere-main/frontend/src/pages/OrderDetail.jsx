import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { fetchOrderById } from '../services/orderService'
import { payForOrder } from '../services/paymentService'
import { useAuth } from '../context/AuthContext'

const steps = ['PENDING', 'PAID', 'SHIPPED', 'DELIVERED']

export default function OrderDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [order, setOrder] = useState(null)
  const [error, setError] = useState('')
  const [paying, setPaying] = useState(false)

  useEffect(() => {
    fetchOrderById(id).then((res) => setOrder(res.data)).catch(() => setError('Order not found.'))
  }, [id])

  const handlePayNow = () => {
    setPaying(true)
    payForOrder({
      orderId: id,
      userName: user?.fullName,
      userEmail: user?.email,
      onSuccess: () => navigate(`/orders/${id}/payment-success`),
      onFailure: (err) => {
        setPaying(false)
        navigate(`/orders/${id}/payment-failed`, { state: { message: err.message } })
      },
    })
  }

  if (error) return <p className="status-error" style={{ textAlign: 'center', marginTop: 40 }}>{error}</p>
  if (!order) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading...</p>

  const currentStepIndex = steps.indexOf(order.status)
  const isCancelled = order.status === 'CANCELLED'

  return (
    <main className="cart-page">
      <Link to="/orders" className="back-link">&larr; Back to orders</Link>
      <h1>Order #{order.id}</h1>
      <p>{new Date(order.createdAt).toLocaleString()}</p>

      {isCancelled ? (
        <p className="status-error" style={{ marginTop: 16 }}>This order was cancelled.</p>
      ) : (
        <div className="order-tracker">
          {steps.map((step, i) => (
            <div key={step} className={i <= currentStepIndex ? 'tracker-step active' : 'tracker-step'}>
              <div className="tracker-dot" />
              <span>{step}</span>
            </div>
          ))}
        </div>
      )}

      {order.status === 'PENDING' && (
        <div className="status-card" style={{ marginBottom: 16 }}>
          <p className="status-error">Payment not completed yet for this order.</p>
          <button className="add-to-cart-btn" disabled={paying} onClick={handlePayNow}>
            {paying ? 'Opening payment...' : 'Pay Now'}
          </button>
        </div>
      )}

      {order.shippingAddress && (
        <>
          <h3>Shipping to</h3>
          <p>{order.shippingAddress.fullName} &middot; {order.shippingAddress.phone}</p>
          <p>{order.shippingAddress.line1}, {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}</p>
        </>
      )}

      <h3>Items</h3>
      <div className="cart-list">
        {order.items.map((item, i) => (
          <div className="cart-row" key={i}>
            <img src={item.imageUrl || 'https://picsum.photos/seed/placeholder/500'} alt={item.productName} />
            <div className="cart-row-info">
              <h3>{item.productName}</h3>
              <p>Qty: {item.quantity} &times; ${Number(item.unitPrice).toFixed(2)}</p>
            </div>
            <div className="cart-row-total">${Number(item.lineTotal).toFixed(2)}</div>
          </div>
        ))}
      </div>

      <div className="cart-summary">
        <div className="cart-summary-row"><span>Subtotal</span><span>${Number(order.subtotal).toFixed(2)}</span></div>
        <div className="cart-summary-row"><span>Discount</span><span>-${Number(order.discount).toFixed(2)}</span></div>
        <div className="cart-summary-row"><strong>Total</strong><strong>${Number(order.totalAmount).toFixed(2)}</strong></div>
      </div>
    </main>
  )
}
