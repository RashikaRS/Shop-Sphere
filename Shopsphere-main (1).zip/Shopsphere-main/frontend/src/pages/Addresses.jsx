import { useEffect, useState } from 'react'
import { fetchAddresses, createAddress, updateAddress, deleteAddress } from '../services/orderService'

const emptyForm = { fullName: '', phone: '', line1: '', line2: '', city: '', state: '', postalCode: '', country: 'India', isDefault: false }

export default function Addresses() {
  const [addresses, setAddresses] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [error, setError] = useState('')

  const load = () => {
    setLoading(true)
    fetchAddresses().then((res) => setAddresses(res.data)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm({ ...form, [name]: type === 'checkbox' ? checked : value })
  }

  const startEdit = (addr) => {
    setForm(addr)
    setEditingId(addr.id)
    setShowForm(true)
  }

  const startAdd = () => {
    setForm(emptyForm)
    setEditingId(null)
    setShowForm(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      if (editingId) {
        await updateAddress(editingId, form)
      } else {
        await createAddress(form)
      }
      setShowForm(false)
      load()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save address.')
    }
  }

  const handleDelete = async (id) => {
    await deleteAddress(id)
    load()
  }

  if (loading) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading addresses...</p>

  return (
    <main className="cart-page">
      <h1>Your Addresses</h1>

      {!showForm && <button className="cta-link" style={{ border: 'none', cursor: 'pointer' }} onClick={startAdd}>+ Add New Address</button>}

      {showForm && (
        <form className="address-form" onSubmit={handleSubmit}>
          {error && <p className="status-error">{error}</p>}
          <input name="fullName" placeholder="Full name" value={form.fullName} onChange={handleChange} required />
          <input name="phone" placeholder="Phone" value={form.phone} onChange={handleChange} required />
          <input name="line1" placeholder="Address line 1" value={form.line1} onChange={handleChange} required />
          <input name="line2" placeholder="Address line 2 (optional)" value={form.line2 || ''} onChange={handleChange} />
          <div className="price-range">
            <input name="city" placeholder="City" value={form.city} onChange={handleChange} required />
            <input name="state" placeholder="State" value={form.state} onChange={handleChange} required />
          </div>
          <div className="price-range">
            <input name="postalCode" placeholder="Postal code" value={form.postalCode} onChange={handleChange} required />
            <input name="country" placeholder="Country" value={form.country} onChange={handleChange} />
          </div>
          <label>
            <input type="checkbox" name="isDefault" checked={!!form.isDefault} onChange={handleChange} /> Set as default
          </label>
          <div className="product-actions">
            <button type="submit" className="add-to-cart-btn">Save Address</button>
            <button type="button" className="wishlist-btn" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </form>
      )}

      <div className="cart-list" style={{ marginTop: 20 }}>
        {addresses.map((addr) => (
          <div className="cart-row" key={addr.id}>
            <div className="cart-row-info">
              <h3>{addr.fullName} {addr.isDefault && <span className="product-category">Default</span>}</h3>
              <p>{addr.line1}{addr.line2 ? `, ${addr.line2}` : ''}, {addr.city}, {addr.state} {addr.postalCode}, {addr.country}</p>
              <p>{addr.phone}</p>
            </div>
            <button className="wishlist-btn" onClick={() => startEdit(addr)}>Edit</button>
            <button className="remove-btn" onClick={() => handleDelete(addr.id)}>Delete</button>
          </div>
        ))}
        {addresses.length === 0 && !showForm && <p className="empty-state">No addresses saved yet.</p>}
      </div>
    </main>
  )
}
