import { useEffect, useState, useCallback } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { fetchProductById } from '../services/productService'
import { addToWishlist } from '../services/cartService'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import ReviewsSection from '../components/ReviewsSection'
import RecommendedProducts from '../components/RecommendedProducts'

export default function ProductDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const { addItem } = useCart()
  const { showToast } = useToast()
  const navigate = useNavigate()
  const [product, setProduct] = useState(null)
  const [activeImage, setActiveImage] = useState(0)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const loadProduct = useCallback(() => {
    fetchProductById(id)
      .then((res) => setProduct(res.data))
      .catch(() => setError('Product not found.'))
  }, [id])

  useEffect(() => { loadProduct() }, [loadProduct])

  const requireLogin = () => navigate('/login')

  const handleAddToCart = async () => {
    if (!user) return requireLogin()
    setBusy(true)
    try {
      await addItem(product.id, 1)
      showToast('Added to cart!', 'success')
    } catch (err) {
      showToast(err.response?.data?.message || 'Could not add to cart.', 'error')
    } finally {
      setBusy(false)
    }
  }

  const handleAddToWishlist = async () => {
    if (!user) return requireLogin()
    setBusy(true)
    try {
      await addToWishlist(product.id)
      showToast('Added to wishlist!', 'success')
    } catch (err) {
      showToast(err.response?.data?.message || 'Could not add to wishlist.', 'error')
    } finally {
      setBusy(false)
    }
  }

  if (error) return <p className="status-error" style={{ textAlign: 'center', marginTop: 40 }}>{error}</p>
  if (!product) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading...</p>

  const images = product.imageUrls?.length ? product.imageUrls : ['https://picsum.photos/seed/placeholder/500']

  return (
    <main className="product-detail">
      <Link to="/products" className="back-link">&larr; Back to products</Link>
      <div className="product-detail-grid">
        <div className="product-gallery">
          <img src={images[activeImage]} alt={product.name} className="main-image" />
          {images.length > 1 && (
            <div className="thumbnail-row">
              {images.map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt={`${product.name} ${i + 1}`}
                  className={i === activeImage ? 'thumbnail active' : 'thumbnail'}
                  onClick={() => setActiveImage(i)}
                />
              ))}
            </div>
          )}
        </div>

        <div className="product-info">
          <h1>{product.name}</h1>
          {product.categoryName && <span className="product-category">{product.categoryName}</span>}
          <p className="product-price-large">${Number(product.price).toFixed(2)}</p>
          <p className="product-rating">Rating: {product.averageRating ?? 'N/A'} / 5</p>
          <p className="product-description">{product.description}</p>
          <p className={product.stockQuantity > 0 ? 'status-ok' : 'status-error'}>
            {product.stockQuantity > 0 ? `${product.stockQuantity} in stock` : 'Out of stock'}
          </p>



          <div className="product-actions">
            <button className="add-to-cart-btn" disabled={product.stockQuantity === 0 || busy} onClick={handleAddToCart}>
              Add to Cart
            </button>
            <button className="wishlist-btn" disabled={busy} onClick={handleAddToWishlist}>
              Add to Wishlist
            </button>
          </div>
        </div>
      </div>

      <ReviewsSection productId={product.id} onRatingChange={loadProduct} />
      <RecommendedProducts productId={product.id} />
    </main>
  )
}
