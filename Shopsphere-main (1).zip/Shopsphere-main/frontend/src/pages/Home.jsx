import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../services/api'
import { useAuth } from '../context/AuthContext'

export default function Home() {
  const { user } = useAuth()
  const [status, setStatus] = useState('checking...')
  const [error, setError] = useState(null)

  useEffect(() => {
    api.get('/api/health')
      .then((res) => setStatus(res.data.message))
      .catch(() => setError('Could not reach backend. Is it running?'))
  }, [])

  return (
    <main className="hero">
      <h1>ShopSphere</h1>
      <p>Phase 3: browse the catalog</p>
      <Link to="/products" className="cta-link">Shop Products &rarr;</Link>

      <div className="status-card">
        <strong>Backend connection:</strong>
        {error ? <p className="status-error">{error}</p> : <p className="status-ok">{status}</p>}
      </div>

      <div className="status-card">
        <strong>Auth status:</strong>
        {user ? (
          <p className="status-ok">Logged in as {user.fullName} ({user.email})</p>
        ) : (
          <p>Not logged in — try Register then Login above.</p>
        )}
      </div>
    </main>
  )
}
