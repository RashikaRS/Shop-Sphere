import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <main className="hero">
      <h1>404</h1>
      <p>This page doesn't exist.</p>
      <Link to="/" className="cta-link">Back to Home &rarr;</Link>
    </main>
  )
}
