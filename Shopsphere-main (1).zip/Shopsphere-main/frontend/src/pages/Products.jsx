import { useEffect, useState } from 'react'
import { fetchProducts, fetchCategories } from '../services/productService'
import ProductCard from '../components/ProductCard'

export default function Products() {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [totalPages, setTotalPages] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [filters, setFilters] = useState({
    search: '',
    categoryId: '',
    minPrice: '',
    maxPrice: '',
    sortBy: 'createdAt',
    sortDir: 'desc',
    page: 0,
  })

  useEffect(() => {
    fetchCategories().then((res) => setCategories(res.data)).catch(() => {})
  }, [])

  useEffect(() => {
    setLoading(true)
    setError('')
    const params = {
      ...filters,
      categoryId: filters.categoryId || undefined,
      minPrice: filters.minPrice || undefined,
      maxPrice: filters.maxPrice || undefined,
      search: filters.search || undefined,
      size: 12,
    }
    fetchProducts(params)
      .then((res) => {
        setProducts(res.data.content)
        setTotalPages(res.data.totalPages)
      })
      .catch(() => setError('Could not load products.'))
      .finally(() => setLoading(false))
  }, [filters])

  const updateFilter = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value, page: key === 'page' ? value : 0 }))
  }

  return (
    <main className="products-page">
      <aside className="filters-panel">
        <input
          placeholder="Search products..."
          value={filters.search}
          onChange={(e) => updateFilter('search', e.target.value)}
        />

        <label>Category</label>
        <select value={filters.categoryId} onChange={(e) => updateFilter('categoryId', e.target.value)}>
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>

        <label>Price range</label>
        <div className="price-range">
          <input type="number" placeholder="Min" value={filters.minPrice}
                 onChange={(e) => updateFilter('minPrice', e.target.value)} />
          <input type="number" placeholder="Max" value={filters.maxPrice}
                 onChange={(e) => updateFilter('maxPrice', e.target.value)} />
        </div>

        <label>Sort by</label>
        <select
          value={`${filters.sortBy}-${filters.sortDir}`}
          onChange={(e) => {
            const [sortBy, sortDir] = e.target.value.split('-')
            setFilters((prev) => ({ ...prev, sortBy, sortDir, page: 0 }))
          }}
        >
          <option value="createdAt-desc">Newest</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating-desc">Top Rated</option>
          <option value="name-asc">Name: A-Z</option>
        </select>
      </aside>

      <section className="products-grid-section">
        {error && <p className="status-error">{error}</p>}
        {loading ? (
          <p>Loading products...</p>
        ) : products.length === 0 ? (
          <p className="empty-state">No products match your filters.</p>
        ) : (
          <div className="products-grid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}

        {totalPages > 1 && (
          <div className="pagination">
            <button disabled={filters.page === 0} onClick={() => updateFilter('page', filters.page - 1)}>Prev</button>
            <span>Page {filters.page + 1} of {totalPages}</span>
            <button disabled={filters.page >= totalPages - 1} onClick={() => updateFilter('page', filters.page + 1)}>Next</button>
          </div>
        )}
      </section>
    </main>
  )
}
