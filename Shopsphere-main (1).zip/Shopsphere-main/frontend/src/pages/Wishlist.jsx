import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { fetchWishlist, removeFromWishlist } from '../services/cartService'
import { useCart } from '../context/CartContext'

export default function Wishlist() {
  const [wishlist, setWishlist] = useState({ items: [] })
  const [loading, setLoading] = useState(true)
  const { addItem } = useCart()

  const load = () => {
    setLoading(true)
    fetchWishlist().then((res) => setWishlist(res.data)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleRemove = async (itemId) => {
    const res = await removeFromWishlist(itemId)
    setWishlist(res.data)
  }

  const handleMoveToCart = async (productId, itemId) => {
    await addItem(productId, 1)
    await handleRemove(itemId)
  }

  if (loading) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading wishlist...</p>

  if (!wishlist.items || wishlist.items.length === 0) {
    return (
      <main className="cart-page">
        <h1>Your Wishlist</h1>
        <p className="empty-state">Your wishlist is empty.</p>
        <Link to="/products" className="cta-link">Browse Products &rarr;</Link>
      </main>
    )
  }

  return (
    <main className="cart-page">
      <h1>Your Wishlist</h1>
      <div className="cart-list">
        {wishlist.items.map((item) => (
          <div className="cart-row" key={item.itemId}>
            <img src={item.imageUrl || 'https://picsum.photos/seed/placeholder/500'} alt={item.productName} />
            <div className="cart-row-info">
              <h3>{item.productName}</h3>
              <p>${Number(item.price).toFixed(2)}</p>
              {item.availableStock === 0 && <p className="status-error">Out of stock</p>}
            </div>
            <button
              className="add-to-cart-btn"
              disabled={item.availableStock === 0}
              onClick={() => handleMoveToCart(item.productId, item.itemId)}
            >
              Move to Cart
            </button>
            <button className="remove-btn" onClick={() => handleRemove(item.itemId)}>Remove</button>
          </div>
        ))}
      </div>
    </main>
  )
}
