import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { fetchPaymentStatus } from '../services/paymentService'

export default function PaymentSuccess() {
  const { id } = useParams()
  const [status, setStatus] = useState(null)

  useEffect(() => {
    fetchPaymentStatus(id).then((res) => setStatus(res.data)).catch(() => {})
  }, [id])

  return (
    <main className="payment-result-page">
      <div className="payment-result-card success">
        <div className="payment-icon">&#10003;</div>
        <h1>Payment Successful!</h1>
        <p>Your order #{id} has been confirmed.</p>
        {status && (
          <p className="status-ok">Amount paid: ${Number(status.amount).toFixed(2)}</p>
        )}
        <div className="product-actions" style={{ justifyContent: 'center' }}>
          <Link to={`/orders/${id}`} className="add-to-cart-btn">View Order</Link>
          <Link to="/products" className="wishlist-btn">Continue Shopping</Link>
        </div>
      </div>
    </main>
  )
}
