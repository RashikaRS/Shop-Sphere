import { useState } from 'react'
import { useParams, useLocation, Link, useNavigate } from 'react-router-dom'
import { payForOrder } from '../services/paymentService'
import { useAuth } from '../context/AuthContext'

export default function PaymentFailed() {
  const { id } = useParams()
  const location = useLocation()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [retrying, setRetrying] = useState(false)
  const message = location.state?.message || 'Your payment could not be completed.'

  const handleRetry = () => {
    setRetrying(true)
    payForOrder({
      orderId: id,
      userName: user?.fullName,
      userEmail: user?.email,
      onSuccess: () => navigate(`/orders/${id}/payment-success`),
      onFailure: (err) => {
        setRetrying(false)
        navigate(`/orders/${id}/payment-failed`, { state: { message: err.message }, replace: true })
      },
    })
  }

  return (
    <main className="payment-result-page">
      <div className="payment-result-card failed">
        <div className="payment-icon">&#10007;</div>
        <h1>Payment Failed</h1>
        <p className="status-error">{message}</p>
        <p>Your order #{id} is saved as PENDING — no charge was made. You can retry payment anytime.</p>
        <div className="product-actions" style={{ justifyContent: 'center' }}>
          <button className="add-to-cart-btn" disabled={retrying} onClick={handleRetry}>
            {retrying ? 'Retrying...' : 'Retry Payment'}
          </button>
          <Link to={`/orders/${id}`} className="wishlist-btn">View Order</Link>
        </div>
      </div>
    </main>
  )
}
