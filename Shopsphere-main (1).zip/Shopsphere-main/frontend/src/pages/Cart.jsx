import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useState } from 'react'

export default function Cart() {
  const { cart, loading, updateItem, removeItem, clear } = useCart()
  const [busyItemId, setBusyItemId] = useState(null)
  const navigate = useNavigate()

  const handleQuantityChange = async (itemId, quantity) => {
    setBusyItemId(itemId)
    try {
      await updateItem(itemId, quantity)
    } finally {
      setBusyItemId(null)
    }
  }

  const handleRemove = async (itemId) => {
    setBusyItemId(itemId)
    try {
      await removeItem(itemId)
    } finally {
      setBusyItemId(null)
    }
  }

  if (loading) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading cart...</p>

  if (!cart.items || cart.items.length === 0) {
    return (
      <main className="cart-page">
        <h1>Your Cart</h1>
        <p className="empty-state">Your cart is empty.</p>
        <Link to="/products" className="cta-link">Browse Products &rarr;</Link>
      </main>
    )
  }

  return (
    <main className="cart-page">
      <h1>Your Cart</h1>
      <div className="cart-list">
        {cart.items.map((item) => (
          <div className="cart-row" key={item.itemId}>
            <img src={item.imageUrl || 'https://picsum.photos/seed/placeholder/500'} alt={item.productName} />
            <div className="cart-row-info">
              <h3>{item.productName}</h3>
              <p>${Number(item.unitPrice).toFixed(2)} each</p>
              {item.availableStock < item.quantity && (
                <p className="status-error">Only {item.availableStock} in stock</p>
              )}
            </div>
            <div className="cart-row-qty">
              <button disabled={busyItemId === item.itemId} onClick={() => handleQuantityChange(item.itemId, item.quantity - 1)}>-</button>
              <span>{item.quantity}</span>
              <button disabled={busyItemId === item.itemId} onClick={() => handleQuantityChange(item.itemId, item.quantity + 1)}>+</button>
            </div>
            <div className="cart-row-total">${Number(item.lineTotal).toFixed(2)}</div>
            <button className="remove-btn" disabled={busyItemId === item.itemId} onClick={() => handleRemove(item.itemId)}>Remove</button>
          </div>
        ))}
      </div>

      <div className="cart-summary">
        <div className="cart-summary-row">
          <span>Subtotal ({cart.totalItems} items)</span>
          <strong>${Number(cart.subtotal).toFixed(2)}</strong>
        </div>
        <button className="checkout-btn" onClick={() => navigate('/checkout')}>Proceed to Checkout</button>
        <button className="link-btn" onClick={clear}>Clear cart</button>
      </div>
    </main>
  )
}
