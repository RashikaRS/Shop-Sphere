import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { fetchOrders } from '../services/orderService'

const statusColors = {
  PENDING: '#e67e22',
  PAID: '#2980b9',
  SHIPPED: '#8e44ad',
  DELIVERED: '#1a7f37',
  CANCELLED: '#c0392b',
}

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchOrders({ page: 0, size: 20 })
      .then((res) => setOrders(res.data.content))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading orders...</p>

  if (orders.length === 0) {
    return (
      <main className="cart-page">
        <h1>Your Orders</h1>
        <p className="empty-state">You haven't placed any orders yet.</p>
        <Link to="/products" className="cta-link">Browse Products &rarr;</Link>
      </main>
    )
  }

  return (
    <main className="cart-page">
      <h1>Your Orders</h1>
      <div className="cart-list">
        {orders.map((order) => (
          <Link to={`/orders/${order.id}`} key={order.id} className="cart-row" style={{ textDecoration: 'none', color: 'inherit' }}>
            <div className="cart-row-info">
              <h3>Order #{order.id}</h3>
              <p>{new Date(order.createdAt).toLocaleDateString()} &middot; {order.items.length} item(s)</p>
            </div>
            <span className="product-category" style={{ background: statusColors[order.status] || '#888', color: '#fff' }}>
              {order.status}
            </span>
            <div className="cart-row-total">${Number(order.totalAmount).toFixed(2)}</div>
          </Link>
        ))}
      </div>
    </main>
  )
}
