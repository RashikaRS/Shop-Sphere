import { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { fetchAddresses, checkout, applyCoupon } from '../services/orderService'
import { payForOrder } from '../services/paymentService'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

export default function Checkout() {
  const { cart, refreshCart } = useCart()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [addresses, setAddresses] = useState([])
  const [selectedAddressId, setSelectedAddressId] = useState(null)
  const [loading, setLoading] = useState(true)
  const [placing, setPlacing] = useState(false)
  const [error, setError] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [couponResult, setCouponResult] = useState(null)
  const [couponError, setCouponError] = useState('')
  const [applyingCoupon, setApplyingCoupon] = useState(false)

  useEffect(() => {
    fetchAddresses()
      .then((res) => {
        setAddresses(res.data)
        const def = res.data.find((a) => a.isDefault) || res.data[0]
        if (def) setSelectedAddressId(def.id)
      })
      .finally(() => setLoading(false))
  }, [])

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return
    setApplyingCoupon(true)
    setCouponError('')
    setCouponResult(null)
    try {
      const res = await applyCoupon(couponCode.trim(), cart.subtotal)
      setCouponResult(res.data)
    } catch (err) {
      setCouponError(err.response?.data?.message || 'Invalid coupon.')
    } finally {
      setApplyingCoupon(false)
    }
  }

  const handlePlaceOrder = async () => {
    if (!selectedAddressId) {
      setError('Please select or add a shipping address.')
      return
    }
    setPlacing(true)
    setError('')
    try {
      const orderRes = await checkout(selectedAddressId, couponResult ? couponCode.trim() : undefined)
      const orderId = orderRes.data.id
      await refreshCart()

      // Order is created as PENDING - now launch Razorpay test payment for it.
      await payForOrder({
        orderId,
        userName: user?.fullName,
        userEmail: user?.email,
        onSuccess: () => {
          navigate(`/orders/${orderId}/payment-success`)
        },
        onFailure: (err) => {
          navigate(`/orders/${orderId}/payment-failed`, { state: { message: err.message } })
        },
      })
    } catch (err) {
      setError(err.response?.data?.message || 'Checkout failed.')
    } finally {
      setPlacing(false)
    }
  }

  if (loading) return <p style={{ textAlign: 'center', marginTop: 40 }}>Loading checkout...</p>

  if (!cart.items || cart.items.length === 0) {
    return (
      <main className="cart-page">
        <h1>Checkout</h1>
        <p className="empty-state">Your cart is empty.</p>
        <Link to="/products" className="cta-link">Browse Products &rarr;</Link>
      </main>
    )
  }

  return (
    <main className="cart-page">
      <h1>Checkout</h1>

      <h3>Shipping Address</h3>
      {addresses.length === 0 ? (
        <p>
          No saved addresses. <Link to="/addresses">Add one first</Link>.
        </p>
      ) : (
        <div className="cart-list">
          {addresses.map((addr) => (
            <label className="cart-row" key={addr.id} style={{ cursor: 'pointer' }}>
              <input
                type="radio"
                name="address"
                checked={selectedAddressId === addr.id}
                onChange={() => setSelectedAddressId(addr.id)}
              />
              <div className="cart-row-info">
                <h3>{addr.fullName}</h3>
                <p>{addr.line1}, {addr.city}, {addr.state} {addr.postalCode}</p>
                <p>{addr.phone}</p>
              </div>
            </label>
          ))}
        </div>
      )}

      <h3>Order Summary</h3>
      <div className="cart-list">
        {cart.items.map((item) => (
          <div className="cart-row" key={item.itemId}>
            <img src={item.imageUrl || 'https://picsum.photos/seed/placeholder/500'} alt={item.productName} />
            <div className="cart-row-info">
              <h3>{item.productName}</h3>
              <p>Qty: {item.quantity} &times; ${Number(item.unitPrice).toFixed(2)}</p>
            </div>
            <div className="cart-row-total">${Number(item.lineTotal).toFixed(2)}</div>
          </div>
        ))}
      </div>

      {error && <p className="status-error">{error}</p>}

      <h3>Have a coupon?</h3>
      <div className="price-range" style={{ maxWidth: 320 }}>
        <input
          placeholder="Coupon code (try WELCOME10)"
          value={couponCode}
          onChange={(e) => { setCouponCode(e.target.value); setCouponResult(null) }}
        />
        <button className="wishlist-btn" disabled={applyingCoupon} onClick={handleApplyCoupon}>
          {applyingCoupon ? 'Checking...' : 'Apply'}
        </button>
      </div>
      {couponError && <p className="status-error">{couponError}</p>}
      {couponResult && (
        <p className="status-ok">
          Coupon applied! You save ${Number(couponResult.discount).toFixed(2)}.
        </p>
      )}

      <div className="cart-summary">
        <div className="cart-summary-row">
          <span>Subtotal ({cart.totalItems} items)</span>
          <strong>${Number(cart.subtotal).toFixed(2)}</strong>
        </div>
        {couponResult && (
          <div className="cart-summary-row">
            <span>Discount ({couponResult.code})</span>
            <strong>-${Number(couponResult.discount).toFixed(2)}</strong>
          </div>
        )}
        <div className="cart-summary-row">
          <span>Total</span>
          <strong>${Number(couponResult ? couponResult.newTotal : cart.subtotal).toFixed(2)}</strong>
        </div>
        <button className="checkout-btn" disabled={placing || addresses.length === 0} onClick={handlePlaceOrder}>
          {placing ? 'Processing...' : 'Place Order & Pay'}
        </button>
        <p style={{ fontSize: '0.8rem', color: '#888', textAlign: 'center' }}>
          You'll be redirected to Razorpay's secure test-mode checkout. Use test card
          4111 1111 1111 1111, any future expiry, any CVV.
        </p>
      </div>
    </main>
  )
}
