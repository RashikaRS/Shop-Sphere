import api from './api'

export const fetchDashboardStats = () => api.get('/api/admin/dashboard/stats')
export const fetchLowStockProducts = (params) => api.get('/api/admin/products/low-stock', { params })
export const fetchAllOrders = (params) => api.get('/api/admin/orders', { params })
export const updateOrderStatus = (orderId, status) => api.put(`/api/admin/orders/${orderId}/status`, { status })
export const fetchAllUsers = () => api.get('/api/admin/users')
export const enableUser = (userId) => api.put(`/api/admin/users/${userId}/enable`)
export const disableUser = (userId) => api.put(`/api/admin/users/${userId}/disable`)

// Product/category admin CRUD (endpoints already exist since Phase 3, reused here)
export const createProduct = (data) => api.post('/api/products', data)
export const updateProduct = (id, data) => api.put(`/api/products/${id}`, data)
export const deleteProduct = (id) => api.delete(`/api/products/${id}`)
export const createCategory = (data) => api.post('/api/categories', data)
export const deleteCategory = (id) => api.delete(`/api/categories/${id}`)

// Coupon admin CRUD (endpoints already exist since Phase 7, reused here)
export const fetchAllCoupons = () => api.get('/api/coupons')
export const createCoupon = (data) => api.post('/api/coupons', data)
export const updateCoupon = (id, data) => api.put(`/api/coupons/${id}`, data)
export const deleteCoupon = (id) => api.delete(`/api/coupons/${id}`)
