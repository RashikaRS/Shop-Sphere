import api from './api'

export const fetchProducts = (params) => api.get('/api/products', { params })
export const fetchProductById = (id) => api.get(`/api/products/${id}`)
export const fetchCategories = () => api.get('/api/categories')
