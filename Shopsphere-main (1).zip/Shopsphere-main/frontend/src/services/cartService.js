import api from './api'

export const fetchCart = () => api.get('/api/cart')
export const addToCart = (productId, quantity = 1) => api.post('/api/cart/items', { productId, quantity })
export const updateCartItem = (itemId, quantity) => api.put(`/api/cart/items/${itemId}`, null, { params: { quantity } })
export const removeCartItem = (itemId) => api.delete(`/api/cart/items/${itemId}`)
export const clearCart = () => api.delete('/api/cart')

export const fetchWishlist = () => api.get('/api/wishlist')
export const addToWishlist = (productId) => api.post(`/api/wishlist/items/${productId}`)
export const removeFromWishlist = (itemId) => api.delete(`/api/wishlist/items/${itemId}`)
