import api from './api'

export const fetchReviews = (productId, params) => api.get(`/api/products/${productId}/reviews`, { params })
export const submitReview = (productId, data) => api.post(`/api/products/${productId}/reviews`, data)
export const deleteReview = (reviewId) => api.delete(`/api/reviews/${reviewId}`)
export const fetchRecommendations = (productId, limit = 4) =>
  api.get(`/api/products/${productId}/recommendations`, { params: { limit } })
