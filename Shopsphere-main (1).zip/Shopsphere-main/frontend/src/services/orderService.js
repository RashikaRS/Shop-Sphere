import api from './api'

export const fetchAddresses = () => api.get('/api/addresses')
export const createAddress = (data) => api.post('/api/addresses', data)
export const updateAddress = (id, data) => api.put(`/api/addresses/${id}`, data)
export const deleteAddress = (id) => api.delete(`/api/addresses/${id}`)

export const checkout = (addressId, couponCode) => api.post('/api/orders/checkout', { addressId, couponCode })
export const applyCoupon = (code, cartTotal) => api.post('/api/coupons/apply', { code, cartTotal })
export const fetchOrders = (params) => api.get('/api/orders', { params })
export const fetchOrderById = (id) => api.get(`/api/orders/${id}`)
