import axios from 'axios'
import { toastBus } from '../utils/toastBus'

// Set VITE_API_BASE_URL in your .env (see .env.example)
const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'

const api = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Attach JWT token automatically once we add auth in Phase 2
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('shopsphere_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Global error handling: network failures and server errors get a toast
// automatically, since there's no form field to attach them to. Validation
// errors (400/404/409) are left for the calling component to show inline,
// next to the field/action that caused them, since a toast alone wouldn't
// give enough context there.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (!error.response) {
      toastBus.emit('Network error - please check your connection.', 'error')
    } else if (error.response.status === 401) {
      const isAuthEndpoint = error.config?.url?.includes('/api/auth/')
      if (!isAuthEndpoint) {
        toastBus.emit('Your session has expired. Please log in again.', 'error')
        localStorage.removeItem('shopsphere_token')
      }
    } else if (error.response.status >= 500) {
      toastBus.emit('Something went wrong on our end. Please try again.', 'error')
    }
    return Promise.reject(error)
  }
)

export default api
