import api from './api'

export const createRazorpayOrder = (orderId) => api.post(`/api/payments/create-order/${orderId}`)
export const verifyPayment = (data) => api.post('/api/payments/verify', data)
export const fetchPaymentStatus = (orderId) => api.get(`/api/payments/status/${orderId}`)

// Loads the Razorpay Checkout script once and reuses it on subsequent calls.
let razorpayScriptPromise = null
export function loadRazorpayScript() {
  if (razorpayScriptPromise) return razorpayScriptPromise
  razorpayScriptPromise = new Promise((resolve, reject) => {
    if (window.Razorpay) {
      resolve(true)
      return
    }
    const script = document.createElement('script')
    script.src = 'https://checkout.razorpay.com/v1/checkout.js'
    script.onload = () => resolve(true)
    script.onerror = () => reject(new Error('Failed to load Razorpay checkout script'))
    document.body.appendChild(script)
  })
  return razorpayScriptPromise
}

/**
 * Full Razorpay Checkout flow for a ShopSphere order:
 * 1. Load the checkout.js script
 * 2. Ask our backend to create a Razorpay order (test mode) for this order
 * 3. Open Razorpay Checkout with those details
 * 4. On success, send the payment id/order id/signature to our backend for
 *    SERVER-SIDE verification (never trust the frontend callback alone)
 */
export async function payForOrder({ orderId, userName, userEmail, onSuccess, onFailure }) {
  try {
    await loadRazorpayScript()
    const { data } = await createRazorpayOrder(orderId)

    const options = {
      key: data.keyId,
      amount: data.amountInPaise,
      currency: data.currency,
      name: 'ShopSphere',
      description: `Payment for Order #${data.internalOrderId}`,
      order_id: data.razorpayOrderId,
      prefill: { name: userName, email: userEmail },
      theme: { color: '#1a1a2e' },
      handler: async function (response) {
        try {
          const verifyRes = await verifyPayment({
            orderId: data.internalOrderId,
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature,
          })
          onSuccess(verifyRes.data)
        } catch (err) {
          onFailure(err)
        }
      },
      modal: {
        ondismiss: function () {
          onFailure(new Error('Payment was cancelled.'))
        },
      },
    }

    const rzp = new window.Razorpay(options)
    rzp.on('payment.failed', function (response) {
      onFailure(new Error(response.error?.description || 'Payment failed.'))
    })
    rzp.open()
  } catch (err) {
    onFailure(err)
  }
}
