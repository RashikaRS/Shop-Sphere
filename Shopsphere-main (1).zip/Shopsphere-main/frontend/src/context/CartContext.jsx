import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { useAuth } from './AuthContext'
import { fetchCart, addToCart as apiAddToCart, updateCartItem as apiUpdateCartItem, removeCartItem as apiRemoveCartItem, clearCart as apiClearCart } from '../services/cartService'

const CartContext = createContext(null)

export function CartProvider({ children }) {
  const { user } = useAuth()
  const [cart, setCart] = useState({ items: [], subtotal: 0, totalItems: 0 })
  const [loading, setLoading] = useState(false)

  const refreshCart = useCallback(() => {
    if (!user) {
      setCart({ items: [], subtotal: 0, totalItems: 0 })
      return
    }
    setLoading(true)
    fetchCart()
      .then((res) => setCart(res.data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [user])

  useEffect(() => {
    refreshCart()
  }, [refreshCart])

  const addItem = async (productId, quantity = 1) => {
    const res = await apiAddToCart(productId, quantity)
    setCart(res.data)
    return res.data
  }

  const updateItem = async (itemId, quantity) => {
    const res = await apiUpdateCartItem(itemId, quantity)
    setCart(res.data)
  }

  const removeItem = async (itemId) => {
    const res = await apiRemoveCartItem(itemId)
    setCart(res.data)
  }

  const clear = async () => {
    await apiClearCart()
    setCart({ items: [], subtotal: 0, totalItems: 0 })
  }

  return (
    <CartContext.Provider value={{ cart, loading, addItem, updateItem, removeItem, clear, refreshCart }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
