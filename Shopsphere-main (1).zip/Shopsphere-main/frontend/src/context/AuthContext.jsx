import { createContext, useContext, useEffect, useState } from 'react'
import { loginUser, registerUser, fetchCurrentUser } from '../services/authService'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('shopsphere_token')
    if (!token) {
      setLoading(false)
      return
    }
    fetchCurrentUser()
      .then((res) => setUser(res.data))
      .catch(() => {
        localStorage.removeItem('shopsphere_token')
      })
      .finally(() => setLoading(false))
  }, [])

  const login = async (email, password) => {
    const res = await loginUser({ email, password })
    localStorage.setItem('shopsphere_token', res.data.token)
    setUser({
      id: res.data.userId,
      fullName: res.data.fullName,
      email: res.data.email,
      roles: res.data.roles,
    })
    return res.data
  }

  const register = async (fullName, email, password, phone) => {
    const res = await registerUser({ fullName, email, password, phone })
    localStorage.setItem('shopsphere_token', res.data.token)
    setUser({
      id: res.data.userId,
      fullName: res.data.fullName,
      email: res.data.email,
      roles: res.data.roles,
    })
    return res.data
  }

  const logout = () => {
    localStorage.removeItem('shopsphere_token')
    setUser(null)
  }

  const isAdmin = !!user?.roles?.includes('ROLE_ADMIN')

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, isAdmin }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
